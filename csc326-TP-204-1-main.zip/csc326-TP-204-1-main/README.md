# csc326-TP-204-1

## Extra Credit
1. Additional User Role: Added a new manager role who can update inventory and add ingredients to inventory. A new manager account can be created by clicking on the manager radio button at the bottom of the Create Account form. The login would be the same as the customer and staff.
2. Order History: Staff and manager can see the order history of all the orders by choosing the "Order History" option from each of their home pages.
3. Privacy Policy: While logging in, you have to accecpt the privacy policy in order to be able to log in succesfully. The privacy policy can be viewed by clicking the "Terms and Conditions" which opens up on another tab.
4. Security Audit: Security evaluation of CoffeeMaker - https://github.ncsu.edu/engr-csc326-spring2024/csc326-TP-204-1/wiki/Security-Audit
