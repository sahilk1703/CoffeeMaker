package edu.ncsu.csc.CoffeeMaker.api;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

/**
 * Tests methods the APICoffeeController class
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@ExtendWith ( SpringExtension.class )
@SpringBootTest
@AutoConfigureMockMvc
public class APICoffeeTest {

    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    @Autowired
    private MockMvc          mvc;

    /** Represents an instance of the RecipeService */
    @Autowired
    private RecipeService    service;

    /** Represents an instance of the InventoryService */
    @Autowired
    private InventoryService iService;

    /**
     * Sets up the tests by adding new ingredients to the inventory which is
     * saved to the database and creates a new recipe with some ingredients and
     * adds it to the database
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
        iService.deleteAll();

        final Inventory ivt = iService.getInventory();

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        final IngredientInInventory i2 = new IngredientInInventory( "Chocolate", 10 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        final IngredientInInventory i4 = new IngredientInInventory( "Sugar", 10 );
        final IngredientInInventory i5 = new IngredientInInventory( "Pumpkin_Spice", 10 );

        ivt.addIngredient( i1 );
        ivt.addIngredient( i2 );
        ivt.addIngredient( i3 );
        ivt.addIngredient( i4 );
        ivt.addIngredient( i5 );

        iService.save( ivt );

        final Ingredient i6 = new Ingredient( "Coffee", 10 );
        final Ingredient i7 = new Ingredient( "Chocolate", 10 );
        final Ingredient i8 = new Ingredient( "Milk", 10 );
        final Ingredient i9 = new Ingredient( "Sugar", 10 );
        final Ingredient i10 = new Ingredient( "Pumpkin_Spice", 10 );

        final Recipe recipe = new Recipe();
        recipe.setName( "Coffee" );
        recipe.setPrice( 50 );

        recipe.addIngredient( i6 );
        recipe.addIngredient( i7 );
        recipe.addIngredient( i8 );
        recipe.addIngredient( i9 );
        recipe.addIngredient( i10 );

        service.save( recipe );
    }

    /**
     * Tests the makeCoffee() method from the APICoffeeController class by
     * making coffee using a valid recipe with valid ingredients and the
     * sufficient amount required for that recipe
     *
     * @throws Exception
     *             if unable to make the coffee with the amount or the recipe
     */
    @Test
    @Transactional
    public void testPurchaseBeverage1 () throws Exception {

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name ) ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 60 ) ) ).andExpect( status().isOk() )
                .andExpect( jsonPath( "$.message" ).value( 10 ) );

    }

    /**
     * Tests the makeCoffee() method from the APICoffeeController class by
     * making coffee using a valid recipe with valid ingredients and the
     * insufficient amount for that recipe
     *
     * @throws Exception
     *             if unable to make the coffee with the amount or the recipe
     */
    @Test
    @Transactional
    public void testPurchaseBeverage2 () throws Exception {
        /* Insufficient amount paid */

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name ) ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 40 ) ) ).andExpect( status().is4xxClientError() );

    }

    /**
     * Tests the makeCoffee() method from the APICoffeeController class by
     * making coffee using a valid recipe and sufficient amount for that recipe,
     * but with not enough ingredients in the inventory
     *
     * @throws Exception
     *             if unable to make the coffee with the amount or the recipe
     */
    @Test
    @Transactional
    public void testPurchaseBeverage3 () throws Exception {
        /* Insufficient inventory */

        final Inventory ivt = iService.getInventory();
        final IngredientInInventory i6 = new IngredientInInventory( "Pumpkin_Spice", 0 );

        ivt.addIngredient( i6 );
        iService.save( ivt );

        final String name = "Coffee";

        mvc.perform( post( String.format( "/api/v1/makecoffee/%s", name ) ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 50 ) ) ).andExpect( status().is4xxClientError() );

    }

}
