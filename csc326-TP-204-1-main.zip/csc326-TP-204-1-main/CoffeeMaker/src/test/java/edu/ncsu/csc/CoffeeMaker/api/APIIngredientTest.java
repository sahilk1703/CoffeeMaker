package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.services.IngredientService;

/**
 * Tests methods from the APIIngredientController class
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith ( SpringExtension.class )
public class APIIngredientTest {

    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    private MockMvc               mvc;

    @Autowired
    private WebApplicationContext context;

    /** Represents an instance of IngredientService */
    @Autowired
    private IngredientService     service;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();

        service.deleteAll();

    }

    /**
     * Tests the createIngredient() method from the APIIngredientController
     * class by adding a new valid ingredient using the end points and testing
     * the number of ingredients and an ingredient with the same name as has
     * been added earlier
     *
     * @throws Exception
     *             if unable to create or add the ingredient
     */
    @Test
    @Transactional
    public void addIngredientTest () throws Exception {

        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        service.save( i1 );
        final Ingredient i2 = new Ingredient( "Sugar", 4 );
        service.save( i2 );

        final Ingredient i3 = new Ingredient( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        final Ingredient i4 = new Ingredient( "Pumpkin_Spice", 3 );

        // adds a valid ingredient
        mvc.perform( post( "/api/v1/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i4 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 4, (int) service.count() );

        final Ingredient i5 = new Ingredient( "Coffee", 5 );

        // adds an invalid ingredient
        mvc.perform( post( "/api/v1/ingredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i5 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 4, (int) service.count() );
    }

    /**
     * Tests the getIngredient() method from the APIIngredientController class
     * by adding ingredients to the service, and using the get end point to
     * retrieve one of those ingredients, and attempting to retrieve an
     * ingredient that has not been added yet
     *
     * @throws UnsupportedEncodingException
     *             if the character sequence is invalid
     * @throws Exception
     *             if unable to retrieve the ingredients added
     */
    @Test
    @Transactional
    public void getIngredientTest () throws UnsupportedEncodingException, Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        service.save( i1 );
        final Ingredient i2 = new Ingredient( "Sugar", 4 );
        service.save( i2 );

        final Ingredient i3 = new Ingredient( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        // retrieves a valid ingredient added previously
        String ingredient = mvc.perform( get( "/api/v1/ingredients/COFFEE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( ingredient.contains( "Coffee" ) );

        // retrieves a valid ingredient added previously
        ingredient = mvc.perform( get( "/api/v1/ingredients/SUGAR" ) ).andDo( print() ).andExpect( status().isOk() )
                .andReturn().getResponse().getContentAsString();

        assertTrue( ingredient.contains( "Sugar" ) );

        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

        // retrieves an invalid ingredient that hasn't been added previously
        ingredient = mvc.perform( get( "/api/v1/ingredients/PUMPKIN_SPICE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

    }

    /**
     * Tests the getIngredients() method from the APIIngredientController class
     * by retrieving the complete list of ingredients added to the list while
     * testing for those ingredients added and those that have not been added
     *
     * @throws UnsupportedEncodingException
     *             if the character sequence is invalid
     * @throws Exception
     *             if unable to add or retrieve the ingredients
     */
    @Test
    @Transactional
    public void getIngredientListTest () throws UnsupportedEncodingException, Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        service.save( i1 );
        final Ingredient i2 = new Ingredient( "Sugar", 4 );
        service.save( i2 );

        final Ingredient i3 = new Ingredient( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        final String ingredient = mvc.perform( get( "/api/v1/ingredients" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        // tests if the added ingredients exist in the returned string
        assertTrue( ingredient.contains( "Coffee" ) );
        assertTrue( ingredient.contains( "Sugar" ) );
        assertTrue( ingredient.contains( "Milk" ) );
        // tests if an ingredient that hasn't been added exists
        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

    }

    /**
     * Tests the deleteIngredient() method from the APIIngredientController
     * class by adding ingredients and deleting an ingredient from those that
     * have been added and an ingredient that has not been added
     *
     * @throws Exception
     *             if unable to add or delete the ingredients
     */
    @Test
    @Transactional
    public void deleteIngredientTest () throws Exception {

        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        service.save( i1 );
        final Ingredient i2 = new Ingredient( "Sugar", 4 );
        service.save( i2 );

        final Ingredient i3 = new Ingredient( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        // tests deleting a valid ingredient that exists
        mvc.perform( delete( "/api/v1/ingredients/Coffee" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 2, (int) service.count() );

        // test deleting an invalid ingredient that does not exist
        mvc.perform( delete( "/api/v1/ingredients/CHOCOLATE" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i1 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 2, (int) service.count() );

    }

}
