package edu.ncsu.csc.CoffeeMaker.unit;

import static org.hamcrest.Matchers.containsString;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.customerOrder.CustomerOrders;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.OrderService;
import edu.ncsu.csc.CoffeeMaker.services.UserService;
import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * The OrderTest class is designed to conduct integration tests for the order
 * handling components of the CoffeeMaker application. It focuses on testing
 * various functionalities including adding, deleting, and updating user orders
 * within the system, as well as handling order-related errors. specified
 * business rules and behaves as expected under various scenarios.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class OrderTest {
    /**
     * Represents a instance of OrderService
     */
    @Autowired
    private OrderService          u;
    /**
     * Represents a instance of UserService
     */
    @Autowired
    private UserService           userService;

    @Autowired
    private OrderService          orderService;

    /**
     * Represents a instance of customer order
     */
    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private List<CustomerOrders>  list;
    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    private MockMvc               mvc;

    /**
     *
     */
    @Autowired
    private WebApplicationContext context;

    /**
     * Sets up the tests. Starts off deleting all the recipes.
     */
    @BeforeEach
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();

        u.deleteAll();

        userService.deleteAll();
    }

    /**
     * This test is for api testing and persistence testing of api
     */
    @Test
    @Transactional
    public void testOrder () throws Exception {
        setup();
        u.deleteAll();

        final Recipe r1 = new Recipe();

        r1.setName( "Mocha" );
        r1.setPrice( 350 );
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Sugar", 5 );
        final Ingredient i3 = new Ingredient( "Chocolate", 5 );
        final Ingredient i4 = new Ingredient( "Milk", 5 );

        r1.addIngredient( i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        r1.addIngredient( i4 );

        final List<Recipe> recipes = new ArrayList<Recipe>();
        recipes.add( r1 );

        final User user1 = new User( "fname", "lname", "f@email.com", "asdfghjkl123", "1234567890",
                User.CUSTOMER_ROLE );
        userService.save( user1 );
        final CustomerOrders u1 = new CustomerOrders( user1.getId(), recipes, CustomerOrders.PENDING_STATUS, 6,
                CustomerOrders.CUSTOMER_ROLE );

        System.out.println( user1.getId() );
        Assertions.assertThrows( IllegalArgumentException.class, () -> u1.setAmount( -1 ) );
        Assertions.assertThrows( IllegalArgumentException.class, () -> u1.setRemainingAmount( -1 ) );
        Assertions.assertThrows( IllegalArgumentException.class, () -> u1.setRecipe( null ) );
        Assertions.assertThrows( IllegalArgumentException.class, () -> u1.setStatus( null ) );
        u.save( u1 );

        Assertions.assertEquals( 1, u.count() );

        final CustomerOrders u2 = new CustomerOrders( (long) 1234676810, recipes, CustomerOrders.PENDING_STATUS, 5,
                CustomerOrders.CUSTOMER_ROLE );

        final User user2 = new User( "fname1", "lname1", "f1@email.com", "asdfghjkl123", "1234567890",
                User.CUSTOMER_ROLE );

        final Recipe r2 = new Recipe();
        r2.setName( "Latte" );
        r2.setPrice( 120 );

        final Ingredient i5 = new Ingredient( "Coffee", 5 );
        final Ingredient i6 = new Ingredient( "Sugar", 5 );
        r2.addIngredient( i5 );
        r2.addIngredient( i6 );

        userService.save( user2 );

        // final CustomerOrders u3 = new CustomerOrders( 0L, null,
        // CustomerOrders.PENDING_STATUS, 0,
        // CustomerOrders.CUSTOMER_ROLE );

        mvc.perform( post( "/api/v1/orders/Latte/fname1" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 7 ) ) ).andExpect( status().isOk() );
        Assertions.assertEquals( 2, (int) orderService.count() );

        mvc.perform( post( "/api/v1/orders/Latte/firstName" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 3 ) ) ).andExpect( status().isBadRequest() );
        Assertions.assertEquals( 2, (int) orderService.count() );

        final String status = mvc.perform( get( "/api/v1/orders/fname1/PENDING" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();
        Assertions.assertTrue( status.contains( CustomerOrders.PENDING_STATUS ) );

        final String orderId = mvc.perform( get( "/api/v1/orders/" + u1.getId() ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();
        Assertions.assertTrue( orderId.contains( "Mocha" ) );

        mvc.perform( get( "/api/v1/orders/" + "90" ) ).andDo( print() ).andExpect( status().isNotFound() );

        assertEquals( 1, u.findByIdAndStatus( user1.getId(), CustomerOrders.PENDING_STATUS ).size() );
        u1.updateStatus( CustomerOrders.CANCELLED_STATUS );
        mvc.perform( put( "/api/v1/orders/fulfill/" + u1.getId() ) ).andDo( print() );
        Assertions.assertEquals( 2, (int) orderService.count() );

        assertEquals( 0, u.findByIdAndStatus( user1.getId(), CustomerOrders.PENDING_STATUS ).size() );
        assertEquals( 1, u.findByIdAndStatus( user1.getId(), CustomerOrders.CANCELLED_STATUS ).size() );
        assertEquals( 0, u.findByIdAndStatus( user1.getId(), CustomerOrders.COMPLETED ).size() );

        assertFalse( u1.equals( u2 ) );

        assertEquals( 1234676810, u2.getUserId().longValue() );
        assertEquals( 5, u2.getAmount() );
        assertEquals( 5, u2.getRemainingAmount() );
        assertEquals( CustomerOrders.PENDING_STATUS, u2.getStatus() );
        assertEquals( "Customer", u2.getRole() );

    }

    /**
     * Tests pick up order
     */

    @Test
    @Transactional
    public void testPickupOrder () throws Exception {

        final Recipe r1 = new Recipe();

        r1.setName( "Mocha" );
        r1.setPrice( 350 );
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Sugar", 5 );
        final Ingredient i3 = new Ingredient( "Chocolate", 5 );
        final Ingredient i4 = new Ingredient( "Milk", 5 );

        r1.addIngredient( i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        r1.addIngredient( i4 );

        final List<Recipe> recipes = new ArrayList<Recipe>();
        recipes.add( r1 );

        final User user = new User( "nickdoe", "Doe", "nick@doe.com", "nickpass", "9876523140", User.CUSTOMER_ROLE );
        userService.save( user );

        final CustomerOrders order = new CustomerOrders( user.getId(), recipes, CustomerOrders.READY_FOR_PICKUP, 5,
                User.CUSTOMER_ROLE );
        u.save( order );

        mvc.perform( put( "/api/v1/orders/" + order.getId() ) ).andExpect( status().isOk() )
                .andExpect( jsonPath( "$.message" ).value( "Order Completed" ) );

        final CustomerOrders updatedOrder = orderService.findById( order.getId() );
        Assertions.assertEquals( CustomerOrders.COMPLETED, updatedOrder.getStatus() );

    }

    /**
     * Tests pick up order invalid
     */
    @Test
    @Transactional
    public void testPickupOrderNotFound () throws Exception {
        // Non existing order id
        final Long nonExistentOrderId = 999L;

        mvc.perform( put( "/api/v1/orders/" + nonExistentOrderId ) ).andExpect( status().isNotFound() )
                .andExpect( jsonPath( "$.message" ).value( "No order found with id " + nonExistentOrderId ) );
        Assertions.assertEquals( 0, (int) orderService.count() );

    }

    /**
     * Tests get order status found
     */
    @Test
    @Transactional
    public void testGetOrderStatusFound () throws Exception {
        // Arrange
        final User user = new User( "fname", "lname", "email@example.com", "password123", "1234567890",
                User.CUSTOMER_ROLE );
        userService.save( user );

        final Recipe recipe = new Recipe();
        recipe.setName( "Espresso" );
        recipe.setPrice( 100 );

        final List<Recipe> recipes = new ArrayList<>();
        recipes.add( recipe );

        final CustomerOrders order = new CustomerOrders( user.getId(), recipes, CustomerOrders.PENDING_STATUS, 5,
                CustomerOrders.CUSTOMER_ROLE );
        u.save( order );

        mvc.perform( get( "/api/v1/orders/" + order.getId() + "/status" ).contentType( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() )
                .andExpect( content().string( containsString( CustomerOrders.PENDING_STATUS ) ) );
        assertEquals( order.getStatus(), CustomerOrders.PENDING_STATUS );

        u.updateOrderStatus( order.getId(), CustomerOrders.COMPLETED );

        final CustomerOrders updatedOrder = u.findById( order.getId() );
        assertEquals( CustomerOrders.COMPLETED, updatedOrder.getStatus() );

    }

    /**
     * Tests findAllOrders
     */
    @Test
    @Transactional
    public void testFindAllOrders () {
        final CustomerOrders order1 = new CustomerOrders(); // Set details as
                                                            // needed
        final CustomerOrders order2 = new CustomerOrders(); // Set details as
                                                            // needed
        orderService.save( order1 );
        orderService.save( order2 );

        final List<CustomerOrders> actualOrders = orderService.findAllOrders();

        assertEquals( 2, actualOrders.size() );
    }

    /**
     * Tests fulfillCustomerOrder
     *
     * @throws Exception
     *             id invalid
     */
    @Test
    @Transactional
    public void testFulfillCustomerOrder () throws Exception {
        final User user = new User( "fname", "lname", "fname@example.com", "password", "1234567890",
                User.CUSTOMER_ROLE );
        userService.save( user );

        final Recipe recipe = new Recipe();
        recipe.setName( "Coffee" );
        recipe.setPrice( 100 );

        final List<Recipe> recipes = new ArrayList<>();
        recipes.add( recipe );

        final CustomerOrders order = new CustomerOrders( user.getId(), recipes, CustomerOrders.PENDING_STATUS, 1,
                CustomerOrders.CUSTOMER_ROLE );
        orderService.save( order );

        final CustomerOrders fulfilledOrder = orderService.fulfillCustomerOrder( order.getId() );

        assertNotNull( fulfilledOrder );
        assertEquals( CustomerOrders.READY_FOR_PICKUP, fulfilledOrder.getStatus() );

        // Attempt to fulfill a non-existent order
        final CustomerOrders invalidOrder = orderService.fulfillCustomerOrder( 9L );
        assertNull( invalidOrder );
    }

}
