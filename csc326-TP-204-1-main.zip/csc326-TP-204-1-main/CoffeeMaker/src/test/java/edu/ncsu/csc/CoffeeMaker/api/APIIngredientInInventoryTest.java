package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.UnsupportedEncodingException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.services.IngredientInInventoryService;

/**
 * Tests methods from the APIInventoryIngredientController class
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith ( SpringExtension.class )
public class APIIngredientInInventoryTest {

    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    private MockMvc                      mvc;

    @Autowired
    private WebApplicationContext        context;

    /** Represents an instance of IngredientService */
    @Autowired
    private IngredientInInventoryService service;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();

        service.deleteAll();

    }

    /**
     * TODO
     *
     * @throws Exception
     *             if unable to create or add the ingredient
     */
    @Test
    @Transactional
    public void addInventoryIngredientTest () throws Exception {

        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the inventory" );

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Sugar", 4 );
        service.save( i2 );

        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        final IngredientInInventory i4 = new IngredientInInventory( "Pumpkin_Spice", 3 );

        // adds a valid ingredient
        mvc.perform( post( "/api/v1/inventoryIngredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i4 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 4, (int) service.count() );

        final IngredientInInventory i5 = new IngredientInInventory( "Coffee", 5 );

        // adds an invalid ingredient
        mvc.perform( post( "/api/v1/inventoryIngredients" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i5 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 4, (int) service.count() );
    }

    /**
     * Tests the getIngredient() method from the
     * APIInvenetoryIngredientController class by adding ingredients to the
     * service, and using the get end point to retrieve one of those
     * ingredients, and attempting to retrieve an ingredient that has not been
     * added yet TODO
     *
     * @throws UnsupportedEncodingException
     *             if the character sequence is invalid
     * @throws Exception
     *             if unable to retrieve the ingredients added
     */
    @Test
    @Transactional
    public void getInventoryIngredientTest () throws UnsupportedEncodingException, Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the inventory" );

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Sugar", 4 );
        service.save( i2 );

        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        // retrieves a valid ingredient added previously
        String ingredient = mvc.perform( get( "/api/v1/inventoryIngredients/COFFEE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( ingredient.contains( "Coffee" ) );

        // retrieves a valid ingredient added previously
        ingredient = mvc.perform( get( "/api/v1/inventoryIngredients/SUGAR" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertTrue( ingredient.contains( "Sugar" ) );

        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

        // retrieves an invalid ingredient that hasn't been added previously
        ingredient = mvc.perform( get( "/api/v1/inventoryIngredients/PUMPKIN_SPICE" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

    }

    /**
     * Tests the getIngredients() method from the APIIngredientController class
     * by retrieving the complete list of ingredients added to the list while
     * testing for those ingredients added and those that have not been added
     * TODO
     *
     * @throws UnsupportedEncodingException
     *             if the character sequence is invalid
     * @throws Exception
     *             if unable to add or retrieve the ingredients
     */
    @Test
    @Transactional
    public void getInventoryIngredientListTest () throws UnsupportedEncodingException, Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the inventory" );

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Sugar", 4 );
        service.save( i2 );

        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        final String ingredient = mvc.perform( get( "/api/v1/inventoryIngredients" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        // tests if the added ingredients exist in the returned string
        assertTrue( ingredient.contains( "Coffee" ) );
        assertTrue( ingredient.contains( "Sugar" ) );
        assertTrue( ingredient.contains( "Milk" ) );
        // tests if an ingredient that hasn't been added exists
        assertFalse( ingredient.contains( "Pumpkin_Spice" ) );

    }

    /**
     * Tests the deleteIngredient() method from the APIIngredientController
     * class by adding ingredients and deleting an ingredient from those that
     * have been added and an ingredient that has not been added TODO
     *
     * @throws Exception
     *             if unable to add or delete the ingredients
     */
    @Test
    @Transactional
    public void deleteInventoryIngredientTest () throws Exception {

        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no ingredients in the inventory" );

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Sugar", 4 );
        service.save( i2 );

        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 5 );
        service.save( i3 );

        Assertions.assertEquals( 3, (int) service.count() );

        // tests deleting a valid ingredient that exists
        mvc.perform( delete( "/api/v1/inventoryIngredients/Coffee" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 2, (int) service.count() );

        // test deleting an invalid ingredient that does not exist
        mvc.perform( delete( "/api/v1/inventoryIngredients/CHOCOLATE" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i1 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 2, (int) service.count() );

    }

}
