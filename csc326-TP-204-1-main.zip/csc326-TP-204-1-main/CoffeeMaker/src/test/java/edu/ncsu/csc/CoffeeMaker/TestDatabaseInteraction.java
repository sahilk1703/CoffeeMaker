package edu.ncsu.csc.CoffeeMaker;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

@RunWith ( SpringRunner.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )

public class TestDatabaseInteraction {

    @Autowired
    private RecipeService recipeService;

    // @Autowired
    // private OrderService orderService;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        recipeService.deleteAll();
    }

    /**
     * Tests the RecipeService class
     */
    @Test
    @Transactional
    public void testRecipes () {

        setup();

        final Recipe r1 = new Recipe();

        r1.setName( "Mocha" );
        r1.setPrice( 350 );
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        final Ingredient i2 = new Ingredient( "Sugar", 5 );
        final Ingredient i3 = new Ingredient( "Chocolate", 5 );
        final Ingredient i4 = new Ingredient( "Milk", 5 );

        r1.addIngredient( i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        r1.addIngredient( i4 );
        recipeService.save( r1 );

        final List<Recipe> dbRecipes = recipeService.findAll();

        assertEquals( 1, dbRecipes.size() );

        final Recipe dbRecipe = dbRecipes.get( 0 );

        assertEquals( r1.getName(), dbRecipe.getName() );
        assertEquals( r1.getPrice(), dbRecipe.getPrice() );
        assertEquals( r1.getIngredient( "Coffee" ), dbRecipe.getIngredient( "Coffee" ) );
        assertEquals( r1.getIngredient( "Sugar" ), dbRecipe.getIngredient( "Sugar" ) );
        assertEquals( r1.getIngredient( "Milk" ), dbRecipe.getIngredient( "Milk" ) );
        assertEquals( r1.getIngredient( "Chocolate" ), dbRecipe.getIngredient( "Chocolate" ) );

        final Recipe newRecipe = recipeService.findByName( "Mocha" );

        assertEquals( r1.getName(), newRecipe.getName() );
        assertEquals( r1.getPrice(), newRecipe.getPrice() );
        assertEquals( r1.getIngredient( "Coffee" ), newRecipe.getIngredient( "Coffee" ) );
        assertEquals( r1.getIngredient( "Sugar" ), newRecipe.getIngredient( "Sugar" ) );
        assertEquals( r1.getIngredient( "Milk" ), newRecipe.getIngredient( "Milk" ) );
        assertEquals( r1.getIngredient( "Chocolate" ), newRecipe.getIngredient( "Chocolate" ) );

        final List<Recipe> recipeList = recipeService.findAll();

        assertEquals( 1, recipeList.size() );

    }

    // /**
    // * Tests the RecipeService class
    // */
    // @Test
    // @Transactional
    // public void testOrder () {
    //
    // final Order o1 = new Order();
    //
    // r1.setName( "Mocha" );
    // r1.setPrice( 350 );
    // final Ingredient i1 = new Ingredient( "Coffee", 5 );
    // final Ingredient i2 = new Ingredient( "Sugar", 5 );
    // final Ingredient i3 = new Ingredient( "Chocolate", 5 );
    // final Ingredient i4 = new Ingredient( "Milk", 5 );
    //
    // r1.addIngredient( i1 );
    // r1.addIngredient( i2 );
    // r1.addIngredient( i3 );
    // r1.addIngredient( i4 );
    // recipeService.save( r1 );
    //
    // final List<Recipe> dbRecipes = recipeService.findAll();
    //
    // assertEquals( 1, dbRecipes.size() );
    //
    // final Recipe dbRecipe = dbRecipes.get( 0 );
    //
    // assertEquals( r1.getName(), dbRecipe.getName() );
    // assertEquals( r1.getPrice(), dbRecipe.getPrice() );
    // assertEquals( r1.getIngredient( "Coffee" ), dbRecipe.getIngredient(
    // "Coffee" ) );
    // assertEquals( r1.getIngredient( "Sugar" ), dbRecipe.getIngredient(
    // "Sugar" ) );
    // assertEquals( r1.getIngredient( "Milk" ), dbRecipe.getIngredient( "Milk"
    // ) );
    // assertEquals( r1.getIngredient( "Chocolate" ), dbRecipe.getIngredient(
    // "Chocolate" ) );
    //
    // final Recipe newRecipe = recipeService.findByName( "Mocha" );
    //
    // assertEquals( r1.getName(), newRecipe.getName() );
    // assertEquals( r1.getPrice(), newRecipe.getPrice() );
    // assertEquals( r1.getIngredient( "Coffee" ), newRecipe.getIngredient(
    // "Coffee" ) );
    // assertEquals( r1.getIngredient( "Sugar" ), newRecipe.getIngredient(
    // "Sugar" ) );
    // assertEquals( r1.getIngredient( "Milk" ), newRecipe.getIngredient( "Milk"
    // ) );
    // assertEquals( r1.getIngredient( "Chocolate" ), newRecipe.getIngredient(
    // "Chocolate" ) );
    //
    // final List<Recipe> recipeList = recipeService.findAll();
    //
    // assertEquals( 1, recipeList.size() );
    //
    // }

}
