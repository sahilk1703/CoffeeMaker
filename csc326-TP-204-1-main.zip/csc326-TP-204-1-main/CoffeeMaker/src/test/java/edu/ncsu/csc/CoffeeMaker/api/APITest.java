package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;

/**
 * This class is responsible for testing the complete CoffeeMaker functionality
 * together
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 */
@ExtendWith ( SpringExtension.class )
@SpringBootTest
@AutoConfigureMockMvc
public class APITest {
    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    private MockMvc               mvc;

    @Autowired
    private WebApplicationContext context;

    /**
     * Sets up the tests.
     */
    @BeforeEach
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();

    }

    /**
     * This test is responsible for retrieving recipes and creating new recipes.
     * The test also adds ingredients to the inventory before updating the
     * inventory records and eventually making the coffee with the ingredients
     * in the inventory.
     *
     * @throws Exception
     */
    @Test
    @Transactional
    public void testAPI () throws Exception {

        setup();

        String recipe = mvc.perform( get( "/api/v1/recipes" ) ).andDo( print() ).andExpect( status().isOk() )
                .andReturn().getResponse().getContentAsString();

        if ( !recipe.contains( "Mocha" ) ) {
            final Recipe newRecipe = new Recipe();
            newRecipe.setName( "Mocha" );
            newRecipe.setPrice( 10 );

            final Ingredient i1 = new Ingredient( "Coffee", 10 );
            final Ingredient i2 = new Ingredient( "Chocolate", 10 );
            final Ingredient i3 = new Ingredient( "Milk", 10 );
            final Ingredient i4 = new Ingredient( "Sugar", 10 );
            final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 10 );

            newRecipe.addIngredient( i1 );
            newRecipe.addIngredient( i2 );
            newRecipe.addIngredient( i3 );
            newRecipe.addIngredient( i4 );
            newRecipe.addIngredient( i5 );

            mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                    .content( TestUtils.asJsonString( newRecipe ) ) ).andExpect( status().isOk() );
        }

        recipe = mvc.perform( get( "/api/v1/recipes" ) ).andDo( print() ).andExpect( status().isOk() ).andReturn()
                .getResponse().getContentAsString();

        assertTrue( recipe.contains( "Mocha" ) );

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );

        final Inventory inventory = new Inventory( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Chocolate", 10 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        final IngredientInInventory i4 = new IngredientInInventory( "Sugar", 10 );
        final IngredientInInventory i5 = new IngredientInInventory( "Pumpkin_Spice", 10 );

        inventory.addIngredient( i2 );
        inventory.addIngredient( i3 );
        inventory.addIngredient( i4 );

        mvc.perform( put( "/api/v1/inventory" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( inventory ) ) ).andExpect( status().isOk() );

        mvc.perform( post( "/api/v1/inventory/ingredient" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i5 ) ) ).andExpect( status().isOk() );

        mvc.perform( put( "/api/v1/inventory/ingredient/Chocolate" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 20 ) ) ).andExpect( status().isOk() );

        final String ivt = mvc.perform( get( "/api/v1/inventory" ) ).andDo( print() ).andExpect( status().isOk() )
                .andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( ivt.contains( "Coffee" ) );
        Assertions.assertTrue( ivt.contains( "Chocolate" ) );
        Assertions.assertTrue( ivt.contains( "Milk" ) );
        Assertions.assertTrue( ivt.contains( "Sugar" ) );
        Assertions.assertTrue( ivt.contains( "Pumpkin_Spice" ) );

        System.out.print( ivt );

        mvc.perform( post( "/api/v1/makecoffee/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 50 ) ) ).andExpect( status().isOk() );

        mvc.perform( post( "/api/v1/makecoffee/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 1 ) ) ).andExpect( status().is4xxClientError() );

    }

}
