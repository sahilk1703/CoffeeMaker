package edu.ncsu.csc.CoffeeMaker.unit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;

/**
 * This class is responsible for testing the inventory functionality by adding
 * valid and invalid ingredients to the inventory, checking the inventory once
 * ingredients are used and consumed, and also checks if enough ingredients
 * exist in the inventory for a given recipe
 *
 * @author shaziam
 * @author rrjadhav
 * @author skancha5
 */
@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class InventoryTest {

    @Autowired
    private InventoryService inventoryService;

    /**
     * Initializes the inventory by adding a few ingredients
     */
    @BeforeEach
    public void setup () {
        final Inventory ivt = inventoryService.getInventory();
        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        final IngredientInInventory i2 = new IngredientInInventory( "Chocolate", 10 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        final IngredientInInventory i4 = new IngredientInInventory( "Sugar", 10 );
        final IngredientInInventory i5 = new IngredientInInventory( "Pumpkin_Spice", 10 );

        ivt.addIngredient( i1 );
        ivt.addIngredient( i2 );
        ivt.addIngredient( i3 );
        ivt.addIngredient( i4 );
        ivt.addIngredient( i5 );

        inventoryService.save( ivt );
    }

    /**
     * This test is responsible for adding ingredients to the recipe and uses
     * those ingredients from the inventory required for the recipe and then
     * finally checks if the inventory is updated with the used ingredients.
     */
    @Test
    @Transactional
    public void testConsumeInventory () {
        final Inventory i = inventoryService.getInventory();

        final Recipe recipe = new Recipe();
        recipe.setName( "Delicious Not-Coffee" );

        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Milk", 2 );

        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );

        recipe.setPrice( 5 );

        i.useIngredients( recipe );

        /*
         * Make sure that all of the inventory fields are now properly updated
         */

        Assertions.assertEquals( 8, (int) i.getIngredient( "Coffee" ).getInventoryAmount() );
        Assertions.assertEquals( 8, (int) i.getIngredient( "Milk" ).getInventoryAmount() );
    }

    /**
     * This test is responsible for adding various ingredients to the inventory
     * and saving the inventory to the service before checking that the amount
     * field is updated while the ingredient was added to the inventory. To be
     * specific, the new amount should be added to the existing amount for a
     * given ingredient in the inventory
     */
    @Test
    @Transactional
    public void testAddInventory1 () {
        Inventory ivt = inventoryService.getInventory();

        final IngredientInInventory i1 = new IngredientInInventory( "Coffee", 10 );
        final IngredientInInventory i2 = new IngredientInInventory( "Chocolate", 10 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        final IngredientInInventory i4 = new IngredientInInventory( "Sugar", 10 );
        final IngredientInInventory i5 = new IngredientInInventory( "Pumpkin_Spice", 10 );

        ivt.addIngredient( i1 );
        ivt.addIngredient( i2 );
        ivt.addIngredient( i3 );
        ivt.addIngredient( i4 );
        ivt.addIngredient( i5 );

        /* Save and retrieve again to update with DB */
        inventoryService.save( ivt );

        ivt = inventoryService.getInventory();

        Assertions.assertEquals( 20, (int) ivt.getIngredient( "Coffee" ).getInventoryAmount(),
                "Adding to the inventory should result in correctly-updated values for coffee" );
        Assertions.assertEquals( 20, (int) ivt.getIngredient( "Milk" ).getInventoryAmount(),
                "Adding to the inventory should result in correctly-updated values for milk" );
        Assertions.assertEquals( 20, (int) ivt.getIngredient( "Chocolate" ).getInventoryAmount(),
                "Adding to the inventory should result in correctly-updated values chocolate" );
        Assertions.assertEquals( 20, (int) ivt.getIngredient( "Sugar" ).getInventoryAmount(),
                "Adding to the inventory should result in correctly-updated values sugar" );
        Assertions.assertEquals( 20, (int) ivt.getIngredient( "Pumpkin_Spice" ).getInventoryAmount(),
                "Adding to the inventory should result in correctly-updated values pumpkin spice" );

    }

    /**
     * This test is responsible for adding a ingredient with invalid units into
     * the inventory and making sure that the ingredient was added to the
     * inventory. Instead, the ingredient's units shouldn't be updated to the
     * invalid units.
     */
    @Test
    @Transactional
    public void testAddInventory2 () {
        final Inventory ivt = inventoryService.getInventory();
        try {
            final IngredientInInventory i1 = new IngredientInInventory( "Coffee", -10 );
            ivt.addIngredient( i1 );
        }
        catch ( final IllegalArgumentException iae ) {
            Assertions.assertEquals( 10, (int) ivt.getIngredient( "Coffee" ).getInventoryAmount(),
                    "Trying to update the Inventory with an invalid value for coffee should result in no changes -- coffee" );
        }
    }

    /**
     * This test is responsible for testing the valid and invalid amounts of a
     * given ingredient in the inventory. This makes sure that no invalid units
     * are added to the inventory.
     */
    @Test
    @Transactional
    public void testCheckIngredient () {
        final Inventory i = inventoryService.getInventory();

        final int milk = i.checkIngredient( "500" );
        Assertions.assertEquals( 500, milk );

        try {
            i.checkIngredient( "-1" );
        }
        catch ( final IllegalArgumentException iae ) {
            // expected
        }

        try {
            i.checkIngredient( "1.0" );
        }
        catch ( final IllegalArgumentException iae ) {
            // expected
        }

    }

    /**
     * This test is responsible for testing that there is enough ingredients in
     * the inventory to make the recipe
     */
    @Test
    @Transactional
    public void testEnoughIngredients () {
        final Inventory i = inventoryService.getInventory();

        final Recipe recipe = new Recipe();
        recipe.setName( "Coffee" );
        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Milk", 3 );
        final Ingredient i3 = new Ingredient( "Sugar", 2 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );
        final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 1 );
        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        recipe.addIngredient( i5 );

        recipe.setPrice( 5 );

        Assertions.assertTrue( i.enoughIngredients( recipe ) );

    }

    /**
     * This test is responsible for testing toString() by first adding
     * ingredients to a recipe and then using those ingredients before checking
     * that the units of ingredients are updated in the inventory once they are
     * used. Then, the toString() is used to check if the ingredients have the
     * right and updated amounts.
     */
    @Test
    @Transactional
    public void testToString () {
        final Inventory i = inventoryService.getInventory();

        final Recipe recipe = new Recipe();
        recipe.setName( "Delicious Not-Coffee" );
        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Milk", 3 );
        final Ingredient i3 = new Ingredient( "Sugar", 2 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );
        final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 1 );
        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        recipe.addIngredient( i5 );
        recipe.setPrice( 5 );

        i.useIngredients( recipe );

        /*
         * Make sure that all of the inventory fields are now properly updated
         */
        Assertions.assertEquals( 8, (int) i.getIngredient( "Coffee" ).getInventoryAmount() );
        Assertions.assertEquals( 7, (int) i.getIngredient( "Milk" ).getInventoryAmount() );
        Assertions.assertEquals( 8, (int) i.getIngredient( "Sugar" ).getInventoryAmount() );
        Assertions.assertEquals( 8, (int) i.getIngredient( "Chocolate" ).getInventoryAmount() );
        Assertions.assertEquals( 9, (int) i.getIngredient( "Pumpkin_Spice" ).getInventoryAmount() );

        final String inventoryString = i.toString();

        Assertions.assertEquals( "Coffee: 8\nChocolate: 8\nMilk: 7\nSugar: 8\nPumpkin_Spice: 9\n", inventoryString );
    }

}
