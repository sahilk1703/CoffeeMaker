package edu.ncsu.csc.CoffeeMaker.unit;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.security.CustomerUserDetails;
import edu.ncsu.csc.CoffeeMaker.services.UserService;
import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * This class tests the User functionalities for creating user, deleting user,
 * authenticating user, and signing up the user.
 *
 * @author Rishima Jadhav
 * @author Satwika Kancharla
 * @author Shazia Muckram
 * @author Aranya Venugopal
 * @author Sahil Kanchan
 * @author Rishi Kamani
 */
@ExtendWith(SpringExtension.class)
@EnableAutoConfiguration
@SpringBootTest(classes = TestConfig.class)
class UserTest {

	/**
	 * Represents a instance of UserService
	 */
	@Autowired
	private UserService u;

	/**
	 * List of the users to fetch the details variable
	 */
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<User> list;
	/**
	 * MockMvc uses Spring's testing framework to handle requests to the REST API
	 */
	private MockMvc mvc;

	/**
	 * web context variable
	 */
	@Autowired
	private WebApplicationContext context;

	/**
	 * User details for the information of the order variable
	 */
	private CustomerUserDetails userDetails;

	/**
	 * Sets up the tests. Starts off deleting all the recipes.
	 */
	@BeforeEach
	public void setup() {
		mvc = MockMvcBuilders.webAppContextSetup(context).build();

		u.deleteAll();
	}

	/**
	 * This test is for adding two users and making sure there are two users in the
	 * database
	 *
	 */
	@Test
	void testUser() throws Exception {
		u.deleteAll();

		final User u1 = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);

		Assertions.assertThrows(IllegalArgumentException.class, () -> u1.setLastName(""), "Invalid last name.");
		Assertions.assertThrows(IllegalArgumentException.class, () -> u1.setFirstName(""), "Invalid first name.");
		Assertions.assertThrows(IllegalArgumentException.class, () -> u1.setRole(""), "Invalid user.role");
		u.save(u1);

		Assertions.assertEquals(1, u.count());

		final User u2 = new User("f1name", "l1name", "f1name@email.com", "csc326TP", "234567890", User.STAFF_ROLE);

		final User u5 = new User();

		mvc.perform(post("/api/v1/signup").contentType(MediaType.APPLICATION_JSON).content(TestUtils.asJsonString(u2)))
				.andExpect(status().isOk());
		mvc.perform(post("/api/v1/signup").contentType(MediaType.APPLICATION_JSON).content(TestUtils.asJsonString(u5)))
				.andExpect(status().isBadRequest());

		assertFalse(u1.equals(u2));
		final User u3 = new User("f1name", "l1name", "f1name@email.com", "csc326TP", "234567890", User.STAFF_ROLE);
		u.save(u3);
		// assertTrue( u2.equals( u3 ) );

		assertEquals("234567890", u3.getPhoneNumber());
		assertEquals("f1name", u3.getFirstName());
		assertEquals("l1name", u3.getLastName());
		assertEquals("csc326TP", u3.getPassword());
		assertEquals("f1name@email.com", u3.getusername());
		assertEquals("Staff", u3.getRole());

		assertTrue(u3.login("f1name@email.com", "csc326TP"));
		assertFalse(u3.login("f1name@gmail.com", "wrong"));

		list = u.findAll();
		assertEquals(3, list.size());
		assertEquals("234567890", list.get(2).getPhoneNumber());
		assertEquals("f1name", list.get(2).getFirstName());
		assertEquals("l1name", list.get(2).getLastName());
		assertEquals("csc326TP", list.get(2).getPassword());
		assertEquals("f1name@email.com", list.get(2).getusername());
		assertEquals("Staff", list.get(2).getRole());
		u.delete(u1);
		assertEquals(2, u.count());

		Assertions.assertThrows(UsernameNotFoundException.class, () -> u.loadUserByUsername("wrong_username"),
				"User Not Found");

	}

	/**
	 * This test is for making sure the user is authenticated
	 */
	@Test
	void testAuthentication() {
		u.deleteAll();
		final User u1 = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		u.save(u1);
		u.saveUser(u1);

		assertTrue(u.authenticate("fname@email.com", "abcdef1234"));
		assertFalse(u.authenticate("fname@email.com", "abcdef12345"));
		assertFalse(u.authenticate("jagho@email.com", "ksjagfewn12"));

		assertEquals(u1.username, u.loadUserByUsername("fname@email.com").getUsername());

		final User u2 = new User("fname2", "lname2", "fname2@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);

		list = new ArrayList<>();

		list.add(u1);
		list.add(u2);
		u.saveAll(list);
		assertEquals(2, u.count());

	}

	/**
	 * Checks if the correct authorities are assigned to a user.
	 */
	@Test
	void testAuthorities() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);

		assertNotNull(userDetails.getAuthorities());
		assertFalse(userDetails.getAuthorities().isEmpty());
		assertEquals(User.CUSTOMER_ROLE, userDetails.getAuthorities().iterator().next().getAuthority());
	}

	/**
	 * Verifies that the user's password is correctly retrieved and managed by
	 * UserDetails.
	 */
	@Test
	void testGetPassword() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);

		assertEquals("abcdef1234", userDetails.getPassword());
	}

	/**
	 * Tests that the account status for expiration is managed and reported
	 * correctly.
	 */
	@Test
	public void testAccountNonExpired() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);
		assertTrue(userDetails.isAccountNonExpired());
	}

	/**
	 * Ensures that user accounts are flagged as non-locked appropriately.
	 */
	@Test
	public void testAccountNonLocked() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);
		assertTrue(userDetails.isAccountNonLocked());
	}

	/**
	 * Confirms that the credentials expiration management is working as expected.
	 */
	@Test
	public void testCredentialNonExpired() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);
		assertTrue(userDetails.isCredentialsNonExpired());
	}

	/**
	 * Validates that the user's enabled status is correctly managed and queried.
	 */
	@Test
	public void testIsEnabled() {
		final User user = new User("fname", "lname", "fname@email.com", "abcdef1234", "123456789", User.CUSTOMER_ROLE);
		userDetails = new CustomerUserDetails(user);
		assertTrue(userDetails.isEnabled());
	}
}
