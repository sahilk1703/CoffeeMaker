package edu.ncsu.csc.CoffeeMaker.unit;

import static org.junit.Assert.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import javax.validation.ConstraintViolationException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

/**
 * This class tests the Recipe functionality by adding recipes, getting recipes,
 * deleting recipes, and updating recipes. It also tests for the validity of the
 * recipes, its fields, hashCode, equals, and toString.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 */
@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class RecipeTest {

    @Autowired
    private RecipeService service;

    /**
     * Deletes all the recipes currently present
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    /**
     * This test is responsible for adding ingredients into a recipe and making
     * sure that the recipes exist with valid fields
     */
    @Test
    @Transactional
    public void testAddRecipe () {

        final Recipe r1 = new Recipe();
        r1.setName( "Black Coffee" );
        r1.setPrice( 1 );
        final Ingredient i1 = new Ingredient( "Coffee", 5 );
        r1.addIngredient( i1 );
        service.save( r1 );

        final Recipe r2 = new Recipe();
        r2.setName( "Mocha" );
        r2.setPrice( 1 );
        final Ingredient i3 = new Ingredient( "Coffee", 5 );
        r2.addIngredient( i3 );
        final Ingredient i2 = new Ingredient( "Chocolate", 4 );
        r2.addIngredient( i2 );
        service.save( r2 );

        final List<Recipe> recipes = service.findAll();
        Assertions.assertEquals( 2, recipes.size(),
                "Creating two recipes should result in two recipes in the database" );

        Assertions.assertEquals( r1, recipes.get( 0 ), "The retrieved recipe should match the created one" );
    }

    /**
     * This test is responsible for adding ingredients into a given recipe with
     * invalid fields and then trying to save an invalid recipe with invalid
     * ingredients
     */
    @Test
    @Transactional
    public void testNoRecipes () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r1 = new Recipe();
        r1.setName( "Tasty Drink" );
        r1.setPrice( 12 );

        try {
            final Ingredient i1 = new Ingredient( "Coffee", -12 );
            r1.addIngredient( i1 );
            Assertions.assertEquals( 0, r1.getIngredients().size(),
                    "Trying to save a collection of elements where one is invalid should result in neither getting saved" );
        }
        catch ( final Exception e ) {
            // expected
        }

        final Ingredient i2 = new Ingredient( "Milk", 4 );
        r1.addIngredient( i2 );

        final Recipe r2 = new Recipe();
        r2.setName( "Mocha" );
        r2.setPrice( 1 );

        final Ingredient i3 = new Ingredient( "Milk", 4 );
        r2.addIngredient( i3 );
        final Ingredient i4 = new Ingredient( "Pumpkin_Spice", 2 );
        r2.addIngredient( i4 );

        service.save( r1 );
        service.save( r2 );

        final List<Recipe> recipes = List.of( r1, r2 );

        try {
            service.saveAll( recipes );
            Assertions.assertEquals( 2, service.count(),
                    "Trying to save a collection of elements where one is invalid should result in neither getting saved" );
        }
        catch ( final Exception e ) {
            Assertions.assertTrue( e instanceof ConstraintViolationException );
        }

    }

    /**
     * This test is responsible for adding ingredients into a recipe and saving
     * the recipe in the database before making sure that the recipe with that
     * name exists.
     *
     */
    @Test
    @Transactional
    public void testAddRecipe1 () {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( name, 50, i1 );

        service.save( r1 );

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
        Assertions.assertNotNull( service.findByName( name ) );

    }

    /**
     * This test is responsible for adding an invalid recipe with a negative
     * price and making sure that the recipe was not added
     *
     */
    @Test
    @Transactional
    public void testAddRecipe2 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( name, -50, i1 );

        try {
            service.save( r1 );

            Assertions.assertNull( service.findByName( name ),
                    "A recipe was able to be created with a negative price" );
        }
        catch ( final ConstraintViolationException cvee ) {
            // expected
        }

    }

    /**
     * This test is responsible for adding an invalid amount for the units of
     * coffee and making sure that the recipe was not added
     *
     */
    @Test
    @Transactional
    public void testAddRecipe3 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";

        try {
            final Ingredient i1 = new Ingredient( "Coffee", -2 );
            final Recipe r1 = createRecipe( name, 50, i1 );
            service.save( r1 );

            Assertions.assertNull( service.findByName( name ),
                    "A recipe was able to be created with a negative amount of coffee" );
        }
        catch ( final Exception e ) {
            // expected
        }

    }

    /**
     * This test is responsible for adding the ingredient coffee to the recipe
     * and then adding the same ingredient to the recipe but with a different
     * amount and then checks if the units of coffee were successfully updated
     *
     */
    @Test
    @Transactional
    public void testAddRecipe4 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( name, 50, i1 );
        final Ingredient i2 = new Ingredient( "Coffee", 4 );

        r1.addIngredient( i2 );
        assertEquals( 1, r1.getIngredients().size() );
        assertEquals( 3, r1.getIngredient( "Coffee" ).getAmount() );

    }

    /**
     * This test creates a new recipe with the ingredient coffee and then
     * creates another new recipe with the ingredient coffee and adds sugar to
     * the new recipe before checking that the two recipe were successfully
     * saved in the database
     *
     */
    @Test
    @Transactional
    public void testAddRecipe5 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        service.save( r1 );

        final Ingredient i2 = new Ingredient( "Coffee", 3 );
        final Recipe r2 = createRecipe( "Mocha", 50, i2 );
        final Ingredient i3 = new Ingredient( "Sugar", 2 );
        r2.addIngredient( i3 );
        service.save( r2 );

        Assertions.assertEquals( 2, service.count(),
                "Creating two recipes should result in two recipes in the database" );

    }

    /**
     * This test creates three new recipes and makes sure that they were
     * successfully added to the database
     *
     */
    @Test
    @Transactional
    public void testAddRecipe6 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        service.save( r1 );

        final Ingredient i2 = new Ingredient( "Coffee", 3 );
        final Recipe r2 = createRecipe( "Mocha", 50, i2 );
        final Ingredient i3 = new Ingredient( "Sugar", 2 );
        r2.addIngredient( i3 );
        service.save( r2 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Ingredient i5 = new Ingredient( "Sugar", 2 );
        final Recipe r3 = createRecipe( "Latte", 60, i4 );
        r3.addIngredient( i5 );
        final Ingredient i6 = new Ingredient( "Milk", 2 );
        r3.addIngredient( i6 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(),
                "Creating three recipes should result in three recipes in the database" );

    }

    /**
     * This test deletes a given recipe and checks if that recipe was removed
     * from the database.
     *
     */
    @Test
    @Transactional
    public void testDeleteRecipe1 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        service.save( r1 );

        Assertions.assertEquals( 1, service.count(), "There should be one recipe in the database" );

        service.delete( r1 );
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
    }

    /**
     * This test deletes all the recipes that exist in the database and makes
     * sure that no recipes now exist in the database
     *
     */
    @Test
    @Transactional
    public void testDeleteRecipe2 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        service.save( r1 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Recipe r2 = createRecipe( "Mocha", 50, i4 );
        final Ingredient i2 = new Ingredient( "Sugar", 2 );
        r2.addIngredient( i2 );
        service.save( r2 );

        final Ingredient i5 = new Ingredient( "Coffee", 3 );
        final Recipe r3 = createRecipe( "Latte", 60, i5 );
        final Ingredient i3 = new Ingredient( "Milk", 2 );
        r3.addIngredient( i3 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(), "There should be three recipes in the database" );

        service.deleteAll();

        Assertions.assertEquals( 0, service.count(), "`service.deleteAll()` should remove everything" );

    }

    /**
     * This test deletes a recipe that was never saved into the database and
     * therefore checks that the original three recipes still exist in the
     * database.
     *
     */
    @Test
    @Transactional
    public void testDeleteRecipe3 () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        service.save( r1 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Recipe r2 = createRecipe( "Mocha", 50, i4 );
        final Ingredient i2 = new Ingredient( "Sugar", 2 );
        r2.addIngredient( i2 );
        service.save( r2 );

        final Ingredient i5 = new Ingredient( "Coffee", 3 );
        final Recipe r3 = createRecipe( "Latte", 60, i5 );
        final Ingredient i3 = new Ingredient( "Milk", 2 );
        r3.addIngredient( i3 );
        service.save( r3 );

        final Recipe r4 = createRecipe( "Cappucino", 70, i1 );
        r4.addIngredient( i2 );
        r4.addIngredient( i3 );
        Assertions.assertEquals( 3, service.count(), "There should be three recipes in the database" );

        service.delete( r4 );

        Assertions.assertEquals( 3, service.count(), "r4 does not exist in the database and should not be deleted." );

    }

    /**
     * This test tests the updateRecipe() method from the Recipe class by
     * updating the price of the recipe to a valid value.
     *
     */
    @Test
    @Transactional
    public void testEditRecipeByPrice () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Recipe r = createRecipe( "Mocha", 45, i1 );
        service.save( r );
        assertEquals( 1, service.count() );

        final Recipe r1 = createRecipe( "Mocha", 50, i1 );
        r.updateRecipe( r1 );
        service.save( r );

        final Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 50, retrieved.getPrice() );

    }

    /**
     * This tests tests the updateRecipe() method from the Recipe class by
     * adding new ingredients (one and two) to the recipe and ensuring that the
     * rest of the ingredients remain the same and the new ingredient is added
     * appropriately.
     *
     */
    @Test
    @Transactional
    public void testEditRecipeByAddingIngredients () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i = new Ingredient( "Coffee", 2 );
        final Recipe r = createRecipe( "Mocha", 45, i );
        service.save( r );
        assertEquals( 1, service.count() );

        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        Recipe r1 = createRecipe( "Mocha", 50, i1 );
        final Ingredient i2 = new Ingredient( "Chocolate", 2 );
        r1.addIngredient( i2 );
        r.updateRecipe( r1 );
        service.save( r );

        Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 2, retrieved.getIngredients().size() );
        assertEquals( i1.getName(), retrieved.getIngredients().get( 0 ).getName() );
        assertEquals( i1.getAmount(), retrieved.getIngredients().get( 0 ).getAmount() );
        assertEquals( i2.getName(), retrieved.getIngredients().get( 1 ).getName() );
        assertEquals( i2.getAmount(), retrieved.getIngredients().get( 1 ).getAmount() );

        final Ingredient i3 = new Ingredient( "Coffee", 2 );
        r1 = createRecipe( "Mocha", 50, i3 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );
        final Ingredient i5 = new Ingredient( "Sugar", 1 );
        r1.addIngredient( i4 );
        r1.addIngredient( i5 );
        r.updateRecipe( r1 );
        service.save( r );

        retrieved = service.findByName( "Mocha" );
        assertEquals( 3, retrieved.getIngredients().size() );
        assertEquals( i3.getName(), retrieved.getIngredients().get( 0 ).getName() );
        assertEquals( i3.getAmount(), retrieved.getIngredients().get( 0 ).getAmount() );
        assertEquals( i4.getName(), retrieved.getIngredients().get( 1 ).getName() );
        assertEquals( i4.getAmount(), retrieved.getIngredients().get( 1 ).getAmount() );
        assertEquals( i5.getName(), retrieved.getIngredients().get( 2 ).getName() );
        assertEquals( i5.getAmount(), retrieved.getIngredients().get( 2 ).getAmount() );
    }

    /**
     * This test tests the updateRecipe() method from the Recipe class by
     * deleting the number of ingredients for the recipe, while ensuring that
     * everything else in the recipe stays constant. It also attempts to delete
     * the only ingredient in the recipe and tests to get an error message.
     *
     */
    @Test
    @Transactional
    public void testEditRecipeByRemovingIngredients () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i = new Ingredient( "Coffee", 2 );
        final Recipe r = createRecipe( "Mocha", 45, i );
        final Ingredient i1 = new Ingredient( "Chocolate", 2 );
        r.addIngredient( i1 );
        service.save( r );
        assertEquals( 1, service.count() );
        assertEquals( 2, r.getIngredients().size() );

        final Ingredient i3 = new Ingredient( "Coffee", 2 );
        final Ingredient i4 = new Ingredient( "Chocolate", 0 );
        final Recipe r1 = createRecipe( "Mocha", 45, i3 );
        r1.addIngredient( i4 );
        r.updateRecipe( r1 );
        service.save( r );

        assertEquals( 1, r.getIngredients().size() );
        final Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 1, retrieved.getIngredients().size() );
        assertEquals( i3.getName(), retrieved.getIngredients().get( 0 ).getName() );
        assertEquals( i3.getAmount(), retrieved.getIngredients().get( 0 ).getAmount() );

        final Ingredient i5 = new Ingredient( "Coffee", 0 );
        final Recipe r2 = createRecipe( "Mocha", 45, i5 );
        assertThrows( IllegalArgumentException.class, () -> r.updateRecipe( r2 ), "No ingredients added." );

    }

    /**
     * This private method is responsible for creating a recipe and setting the
     * appropriate fields such as name, price, and then adding the desired
     * ingredient to the recipe.
     *
     * @param name
     *            refers to the name of the recipe
     * @param price
     *            refers to the price of the recipe
     * @param ingredient
     *            refers to the ingredient to be added to the recipe
     * @return recipe with the set name, price, and ingredients.
     *
     */
    private Recipe createRecipe ( final String name, final Integer price, final Ingredient ingredient ) {
        final Recipe recipe = new Recipe();
        recipe.setName( name );
        recipe.setPrice( price );
        recipe.addIngredient( ingredient );
        return recipe;
    }

    /**
     * This method is responsible for testing the hash code method
     */
    @Test
    @Transactional
    public void testHashCode () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Latte", 54, i1 );
        service.save( r1 );

        final Recipe r2 = service.findByName( "Latte" );

        assertEquals( r1.hashCode(), r2.hashCode() );

        Assertions.assertEquals( 1, service.count() );

        final Ingredient i2 = new Ingredient( "Coffee", 3 );
        final Recipe r3 = createRecipe( "Mocha", 52, i2 );
        service.save( r3 );

        Assertions.assertNotEquals( r1.hashCode(), r3.hashCode() );

        Assertions.assertEquals( 2, service.count() );

        final Ingredient i3 = new Ingredient( "Coffee", 3 );
        final Recipe r4 = createRecipe( null, 54, i3 );
        service.save( r4 );

        assertEquals( 31, r4.hashCode() );
    }

    /**
     * This method is responsible for checking the price of a recipe and makes
     * sure that negative prices returns false indicating invalid price
     */
    @Test
    @Transactional
    public void testCheckRecipe () {

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Latte", 54, i1 );
        service.save( r1 );

        final Recipe r2 = service.findByName( "Latte" );

        assertEquals( r1.hashCode(), r2.hashCode() );

        assertTrue( r2.checkRecipe() );

        final Ingredient i2 = new Ingredient( "Coffee", 3 );
        final Recipe r3 = createRecipe( "Latte", -45, i2 );
        assertFalse( r3.checkRecipe() );

        Assertions.assertEquals( 1, service.count() );

    }

    /**
     * This method is responsible for testing the equals method by checking the
     * equality of the recipes based on their names.
     */
    @Test
    @Transactional
    public void testEquals () {
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Mocha", 46, i1 );
        service.save( r1 );

        final Recipe r2 = service.findByName( "Mocha" );

        assertTrue( r1.equals( r2 ) );
        final Recipe r3 = createRecipe( "Latte", 56, i1 );

        r1.updateRecipe( r3 );
        service.save( r1 );

        assertFalse( r2.equals( r3 ) );

        Assertions.assertEquals( 1, service.count(), "Editing a recipe shouldn't duplicate it" );

    }

    /**
     * This test is responsible for testing the toString method by creating
     * recipes with similar names and checking that their toStrings are the same
     * and vice-versa.
     */
    @Test
    @Transactional
    public void testToString () {

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Recipe r1 = createRecipe( "Mocha", 35, i1 );
        final Recipe r2 = createRecipe( "Mocha", 40, i1 );
        final Recipe r3 = createRecipe( "Latte", 43, i1 );

        final String n1 = r1.toString();
        final String n2 = r2.toString();
        final String n3 = r3.toString();

        assertEquals( n1, n2 );
        assertNotEquals( n1, n3 );

    }

}
