package edu.ncsu.csc.CoffeeMaker;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import edu.ncsu.csc.CoffeeMaker.models.DomainObject;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

/**
 * Creates a new recipe in the database with new ingredients and prints it
 */
@RunWith ( SpringRunner.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class GenerateRecipeWithIngredients {

    /** Represents an instance of recipeService */
    @Autowired
    private RecipeService recipeService;

    /**
     * Deletes all the existing recipes in the database
     */
    @Before
    public void setup () {
        recipeService.deleteAll();
    }

    /**
     * Creates a new recipe object, adds it to the database, and tests the
     * findAll() method by ensuring that the recipe has been added to the
     * database
     */
    @Test
    @Transactional
    public void createRecipe () {
        final Recipe r1 = new Recipe();
        r1.setName( "Delicious Coffee" );

        r1.setPrice( 50 );

        r1.addIngredient( new Ingredient( "Coffee", 10 ) );
        r1.addIngredient( new Ingredient( "Pumpkin_Spice", 3 ) );
        r1.addIngredient( new Ingredient( "Milk", 2 ) );

        recipeService.save( r1 );

        printRecipes();
    }

    /**
     * Prints each of the recipes in the database
     */
    private void printRecipes () {
        for ( final DomainObject r : recipeService.findAll() ) {
            System.out.println( r );
        }
    }

}
