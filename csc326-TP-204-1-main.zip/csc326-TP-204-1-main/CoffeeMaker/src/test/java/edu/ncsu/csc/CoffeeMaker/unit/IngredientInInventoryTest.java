package edu.ncsu.csc.CoffeeMaker.unit;

import static org.junit.Assert.assertEquals;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.TestConfig;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.services.IngredientInInventoryService;

/**
 * This class tests the IngredientInInventory functionality by adding
 * ingredients, getting ingredients, deleting ingredients, and updating
 * ingredients.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 */
@ExtendWith ( SpringExtension.class )
@EnableAutoConfiguration
@SpringBootTest ( classes = TestConfig.class )
public class IngredientInInventoryTest {

    @Autowired
    private IngredientInInventoryService service;

    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private List<IngredientInInventory>  l1;

    /**
     * Deletes all the current ingredients in the service
     */
    @BeforeEach
    public void setup () {
        service.deleteAll();
    }

    /**
     * This test is responsible for adding three ingredients to the service and
     * checking is the ingredients were successfully added
     */
    @Test
    @Transactional
    void testAddInventoryInventoryIngredient () {
        final IngredientInInventory i1 = new IngredientInInventory( "Chocolate", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Coffee", 10 );
        service.save( i2 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        service.save( i3 );

        assertEquals( 3, service.count() );

    }

    /**
     * This test is responsible for saving three recipes into the database and
     * retrieving each of the recipes from the list and make sure they were
     * added properly
     */
    @Test
    @Transactional
    void testRetrieveInventoryInventoryIngredient () {
        final IngredientInInventory i1 = new IngredientInInventory( "Chocolate", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Coffee", 10 );
        service.save( i2 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        service.save( i3 );

        final List<IngredientInInventory> l1 = service.findAll();

        assertEquals( i1, l1.get( 0 ) );
        assertEquals( i2, l1.get( 1 ) );
        assertEquals( i3, l1.get( 2 ) );

    }

    /**
     * This test is responsible for deleting an ingredient from the database and
     * making sure no ingredients exist in the database
     */
    @Test
    @Transactional
    void testDeleteInventoryIngredient () {
        assertEquals( 0, service.count() );
        final IngredientInInventory i1 = new IngredientInInventory( "Chocolate", 10 );
        service.save( i1 );
        // final InventoryIngredient i2 = new InventoryIngredient(
        // InventoryIngredientType.COFFEE, 10 );
        // service.save( i2 );
        // final InventoryIngredient i3 = new InventoryIngredient(
        // InventoryIngredientType.MILK, 10 );
        // service.save( i3 );

        // assertEquals( i1, l1.get( 0 ) );
        // assertEquals( i2, l1.get( 1 ) );
        // assertEquals( i3, l1.get( 2 ) );

        service.delete( i1 );
        l1 = service.findAll();

        assertEquals( 0, l1.size() );

    }

    /**
     * This test is responsible for updating the amount of a given ingredient
     * and making sure that the right ingredient is updated.
     */
    @Test
    @Transactional
    void testUpdateInventoryIngredient () {
        final IngredientInInventory i1 = new IngredientInInventory( "Chocolate", 10 );
        service.save( i1 );
        final IngredientInInventory i2 = new IngredientInInventory( "Coffee", 10 );
        service.save( i2 );
        final IngredientInInventory i3 = new IngredientInInventory( "Milk", 10 );
        service.save( i3 );

        i1.setInventoryAmount( 80 );
        service.save( i1 );

        l1 = service.findAll();

        assertEquals( 80, (int) l1.get( 0 ).getInventoryAmount() );

    }

}
