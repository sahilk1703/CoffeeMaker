package edu.ncsu.csc.CoffeeMaker.api;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import javax.transaction.Transactional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import edu.ncsu.csc.CoffeeMaker.common.TestUtils;
import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

/**
 * This class is responsible for testing the CRUD functionality for
 * APIRecipeController by creating, deleting recipes, etc.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 */
@SpringBootTest
@AutoConfigureMockMvc
@ExtendWith ( SpringExtension.class )
public class APIRecipeTest {

    /**
     * MockMvc uses Spring's testing framework to handle requests to the REST
     * API
     */
    private MockMvc               mvc;

    @Autowired
    private WebApplicationContext context;

    @Autowired
    private RecipeService         service;

    /**
     * Sets up the tests. Starts off deleting all the recipes.
     */
    @BeforeEach
    public void setup () {
        mvc = MockMvcBuilders.webAppContextSetup( context ).build();

        service.deleteAll();
    }

    /**
     * This test creates a new recipe and checks if the recipe could be
     * successfully saved to the inventory
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void ensureRecipe () throws Exception {
        service.deleteAll();

        final Recipe r = new Recipe();
        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        final Ingredient i2 = new Ingredient( "Chocolate", 10 );
        final Ingredient i3 = new Ingredient( "Milk", 10 );
        final Ingredient i4 = new Ingredient( "Sugar", 10 );
        final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 10 );

        r.addIngredient( i1 );
        r.addIngredient( i2 );
        r.addIngredient( i3 );
        r.addIngredient( i4 );
        r.addIngredient( i5 );
        r.setPrice( 10 );
        r.setName( "Mocha" );

        mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r ) ) ).andExpect( status().isOk() );

    }

    /**
     * This test creates a new recipe and adds ingredients into the recipe.
     * Then, it checks the CRUD functionality of get and post to ensure that the
     * recipe was created successfully and exists in the database.
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void testRecipeAPI () throws Exception {

        service.deleteAll();

        final Recipe recipe = new Recipe();
        final Ingredient i1 = new Ingredient( "Coffee", 10 );
        final Ingredient i2 = new Ingredient( "Chocolate", 10 );
        final Ingredient i3 = new Ingredient( "Milk", 10 );
        final Ingredient i4 = new Ingredient( "Sugar", 10 );
        final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 10 );

        recipe.setName( "Delicious Not-Coffee" );
        recipe.addIngredient( i1 );
        recipe.addIngredient( i2 );
        recipe.addIngredient( i3 );
        recipe.addIngredient( i4 );
        recipe.addIngredient( i5 );

        recipe.setPrice( 5 );

        mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( recipe ) ) );

        Assertions.assertEquals( 1, (int) service.count() );

        final String notcoffee = mvc.perform( get( "/api/v1/recipes/Delicious Not-Coffee" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( notcoffee.contains( "Delicious Not-Coffee" ) );

    }

    /**
     * This test creates two recipes with the same name and ensure that the
     * duplicate recipe is not saved before adding a new recipe with a new name
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void testAddRecipe1 () throws Exception {

        /* Tests a recipe with a duplicate name to make sure it's rejected */

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );
        final String name = "Coffee";
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Ingredient i2 = new Ingredient( "Chocolate", 1 );
        final Ingredient i3 = new Ingredient( "Milk", 1 );
        final Recipe r1 = createRecipe( name, 50, i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        service.save( r1 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Ingredient i5 = new Ingredient( "Chocolate", 1 );
        final Ingredient i6 = new Ingredient( "Milk", 1 );
        final Recipe r2 = createRecipe( name, 50, i4 );
        r2.addIngredient( i5 );
        r2.addIngredient( i6 );
        mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r2 ) ) ).andExpect( status().is4xxClientError() );

        Assertions.assertEquals( 1, service.findAll().size(), "There should only one recipe in the CoffeeMaker" );
    }

    /**
     * This test ensures that more than three recipes are not added to meet the
     * use case requirements
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void testAddRecipe2 () throws Exception {

        /* Tests to make sure that our cap of 3 recipes is enforced */

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Ingredient i2 = new Ingredient( "Chocolate", 1 );
        final Ingredient i3 = new Ingredient( "Milk", 1 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        service.save( r1 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Ingredient i5 = new Ingredient( "Chocolate", 1 );
        final Ingredient i6 = new Ingredient( "Milk", 1 );
        final Ingredient i7 = new Ingredient( "Sugar", 2 );
        final Recipe r2 = createRecipe( "Mocha", 50, i4 );
        r2.addIngredient( i5 );
        r2.addIngredient( i6 );
        r2.addIngredient( i7 );
        service.save( r2 );

        final Ingredient i8 = new Ingredient( "Coffee", 3 );
        final Ingredient i9 = new Ingredient( "Chocolate", 2 );
        final Ingredient i10 = new Ingredient( "Milk", 2 );
        final Recipe r3 = createRecipe( "Latte", 60, i8 );
        r3.addIngredient( i9 );
        r3.addIngredient( i10 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(),
                "Creating three recipes should result in three recipes in the database" );

        final Ingredient i11 = new Ingredient( "Chocolate", 2 );
        final Ingredient i12 = new Ingredient( "Milk", 1 );
        final Ingredient i13 = new Ingredient( "Sugar", 2 );
        final Recipe r4 = createRecipe( "Hot Chocolate", 75, i11 );
        r4.addIngredient( i12 );
        r4.addIngredient( i13 );

        mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r4 ) ) ).andExpect( status().isInsufficientStorage() );

        Assertions.assertEquals( 3, service.count(), "Creating a fourth recipe should not get saved" );
    }

    /**
     * This test ensures a recipe is properly deleted and checks for the
     * deletion of an invlaid recipe as well
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void testDeleteRecipe1 () throws Exception {

        /* Tests to make sure that our cap of 3 recipes is enforced */

        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Ingredient i2 = new Ingredient( "Chocolate", 1 );
        final Ingredient i3 = new Ingredient( "Milk", 1 );
        final Recipe r1 = createRecipe( "Coffee", 50, i1 );
        r1.addIngredient( i2 );
        r1.addIngredient( i3 );
        service.save( r1 );

        final Ingredient i4 = new Ingredient( "Coffee", 3 );
        final Ingredient i5 = new Ingredient( "Chocolate", 1 );
        final Ingredient i6 = new Ingredient( "Milk", 1 );
        final Ingredient i7 = new Ingredient( "Sugar", 2 );
        final Recipe r2 = createRecipe( "Mocha", 50, i4 );
        r2.addIngredient( i5 );
        r2.addIngredient( i6 );
        r2.addIngredient( i7 );
        service.save( r2 );

        final Ingredient i8 = new Ingredient( "Coffee", 3 );
        final Ingredient i9 = new Ingredient( "Chocolate", 2 );
        final Ingredient i10 = new Ingredient( "Milk", 2 );
        final Recipe r3 = createRecipe( "Latte", 60, i8 );
        r3.addIngredient( i9 );
        r3.addIngredient( i10 );
        service.save( r3 );

        Assertions.assertEquals( 3, service.count(),
                "Creating three recipes should result in three recipes in the database" );

        mvc.perform( delete( "/api/v1/recipes/Coffee" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 2, service.count(), "There should only be two recipes" );
    }

    /**
     * This test tests the put REST API controller by updating the recipe by
     * updating the price of the recipe and tests that all of the ingredients
     * remain the same. There is also an error checking with attempting to
     * update the price of the recipe to a negative number.
     *
     * @throws Exception
     *             if unable to update the recipe
     */
    @Test
    @Transactional
    public void testEditRecipe1 () throws Exception {

        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Chocolate", 2 );
        final Recipe r = createRecipe( "Mocha", 50, i1 );
        r.addIngredient( i2 );
        service.save( r );
        assertEquals( 1, service.count() );
        assertEquals( r.getPrice(), service.findByName( "Mocha" ).getPrice() );

        final Ingredient i3 = new Ingredient( "Coffee", 2 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );
        final Recipe r1 = createRecipe( "Mocha", 60, i3 );
        r1.addIngredient( i4 );
        mvc.perform( put( "/api/v1/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        final Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 60, retrieved.getPrice() );
        assertEquals( 2, retrieved.getIngredients().size() );
        assertEquals( 2, retrieved.getIngredient( "Coffee" ).getAmount() );
        assertEquals( 2, retrieved.getIngredient( "Chocolate" ).getAmount() );

        r1.setPrice( -10 );
        mvc.perform( put( "/api/v1/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is4xxClientError() );
    }

    /**
     * This test tests the REST API controller by updating the recipe by
     * updating the number of ingredients in the recipe by adding another
     * ingredient with a valid quantity.
     *
     * @throws Exception
     *             if unable to update the recipe
     */
    @Test
    @Transactional
    public void testEditRecipe2 () throws Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Chocolate", 2 );
        final Recipe r = createRecipe( "Mocha", 50, i1 );
        r.addIngredient( i2 );
        service.save( r );
        assertEquals( 1, service.count() );
        assertEquals( r.getIngredients().size(), service.findByName( "Mocha" ).getIngredients().size() );

        final Ingredient i3 = new Ingredient( "Coffee", 2 );
        final Ingredient i4 = new Ingredient( "Chocolate", 2 );
        final Recipe r1 = createRecipe( "Mocha", 50, i3 );
        r1.addIngredient( i4 );
        final Ingredient i5 = new Ingredient( "Pumpkin_Spice", 1 );
        r1.addIngredient( i5 );

        mvc.perform( put( "/api/v1/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        mvc.perform( put( "/api/v1/recipes/Mocha/ingredient/Coffee" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( 3 ) ) ).andExpect( status().isOk() );

        final Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 50, retrieved.getPrice() );
        assertEquals( 3, retrieved.getIngredients().size() );
        assertEquals( 3, retrieved.getIngredient( "Coffee" ).getAmount() );
        assertEquals( 2, retrieved.getIngredient( "Chocolate" ).getAmount() );
        assertEquals( 1, retrieved.getIngredient( "Pumpkin_Spice" ).getAmount() );
    }

    /**
     * This test tests the REST API controller by updating the recipe by
     * removing ingredients from the original recipe. It also tests attempting
     * to remove the only ingredient in the recipe which gives an error.
     *
     * @throws Exception
     *             if unable to update the recipe
     */
    @Test
    @Transactional
    public void testEditRecipe3 () throws Exception {
        service.deleteAll();
        Assertions.assertEquals( 0, service.findAll().size(), "There should be no Recipes in the CoffeeMaker" );

        final Recipe r = new Recipe();
        r.setName( "Mocha" );
        r.setPrice( 50 );
        final Ingredient i1 = new Ingredient( "Coffee", 2 );
        final Ingredient i2 = new Ingredient( "Chocolate", 1 );
        final Ingredient i3 = new Ingredient( "Sugar", 2 );
        r.addIngredient( i1 );
        r.addIngredient( i2 );
        r.addIngredient( i3 );
        service.save( r );
        assertEquals( 1, service.count() );
        assertEquals( r.getIngredients().size(), service.findByName( "Mocha" ).getIngredients().size() );

        Recipe r1 = new Recipe();
        r1.setName( "Mocha" );
        r1.setPrice( 50 );
        final Ingredient i4 = new Ingredient( "Coffee", 2 );
        final Ingredient i5 = new Ingredient( "Chocolate", 1 );
        final Ingredient i6 = new Ingredient( "Sugar", 0 );
        r1.addIngredient( i4 );
        r1.addIngredient( i5 );
        r1.addIngredient( i6 );
        mvc.perform( put( "/api/v1/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        Recipe retrieved = service.findByName( "Mocha" );
        assertEquals( 50, retrieved.getPrice() );
        assertEquals( 2, retrieved.getIngredients().size() );

        mvc.perform( delete( "/api/v1/recipes/Mocha/ingredient/Chocolate" ).contentType( MediaType.APPLICATION_JSON ) )
                .andExpect( status().isOk() );
        retrieved = service.findByName( "Mocha" );
        assertEquals( 1, retrieved.getIngredients().size() );
        assertEquals( 2, retrieved.getIngredient( "Coffee" ).getAmount() );

        r1 = new Recipe();
        r1.setName( "Mocha" );
        r1.setPrice( 50 );
        final Ingredient i7 = new Ingredient( "Coffee", 0 );
        r1.addIngredient( i7 );

        mvc.perform( put( "/api/v1/recipes/Mocha" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().is4xxClientError() );

    }

    /**
     * This test adds ingredients into the recipe by making API calls and
     * ensures that the ingredients were added correctly and successfully into
     * the recipe
     *
     * @throws Exception
     *             if the recipe could not be successfully created
     */
    @Test
    @Transactional
    public void testAddIngredient () throws Exception {
        final Ingredient i1 = new Ingredient( "Coffee", 3 );
        final Ingredient i2 = new Ingredient( "Chocolate", 1 );

        final Recipe r1 = new Recipe();
        r1.setName( "Mocha" );
        r1.setPrice( 10 );

        mvc.perform( post( "/api/v1/recipes" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( r1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 1, service.findAll().size() );
        Assertions.assertEquals( "Mocha", service.findAll().get( 0 ).getName() );
        Assertions.assertEquals( 10, service.findAll().get( 0 ).getPrice() );
        Assertions.assertEquals( 0, service.findAll().get( 0 ).getIngredients().size() );

        mvc.perform( post( "/api/v1/recipes/Mocha/ingredient" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i1 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 1, service.findAll().size() );
        Assertions.assertEquals( "Mocha", service.findAll().get( 0 ).getName() );
        Assertions.assertEquals( 10, service.findAll().get( 0 ).getPrice() );
        Assertions.assertEquals( 1, service.findAll().get( 0 ).getIngredients().size() );
        Assertions.assertEquals( "Coffee", service.findAll().get( 0 ).getIngredients().get( 0 ).getName() );
        Assertions.assertEquals( 3, service.findAll().get( 0 ).getIngredients().get( 0 ).getAmount() );

        mvc.perform( post( "/api/v1/recipes/Mocha/ingredient" ).contentType( MediaType.APPLICATION_JSON )
                .content( TestUtils.asJsonString( i2 ) ) ).andExpect( status().isOk() );

        Assertions.assertEquals( 1, service.findAll().size() );
        Assertions.assertEquals( "Mocha", service.findAll().get( 0 ).getName() );
        Assertions.assertEquals( 10, service.findAll().get( 0 ).getPrice() );
        Assertions.assertEquals( 2, service.findAll().get( 0 ).getIngredients().size() );
        Assertions.assertEquals( "Chocolate", service.findAll().get( 0 ).getIngredients().get( 1 ).getName() );
        Assertions.assertEquals( 1, service.findAll().get( 0 ).getIngredients().get( 1 ).getAmount() );

        final String ingredient = mvc.perform( get( "/api/v1/recipes/Mocha/ingredient/Chocolate" ) ).andDo( print() )
                .andExpect( status().isOk() ).andReturn().getResponse().getContentAsString();

        Assertions.assertTrue( ingredient.contains( "Chocolate" ) );
        Assertions.assertTrue( ingredient.contains( "1" ) );

    }

    /**
     * Private class that is responsible for creating a valid recipe with the
     * appropriate fields and adding valid ingredients to the recipe
     *
     * @param name
     *            refers to the name of the recipe
     * @param price
     *            refers to the price of the recipe
     * @param i
     *            refers to the ingredient to be added
     * @return recipe that was created
     */
    private Recipe createRecipe ( final String name, final Integer price, final Ingredient i ) {
        final Recipe recipe = new Recipe();
        recipe.setName( name );
        recipe.setPrice( price );

        recipe.addIngredient( i );

        return recipe;
    }

}
