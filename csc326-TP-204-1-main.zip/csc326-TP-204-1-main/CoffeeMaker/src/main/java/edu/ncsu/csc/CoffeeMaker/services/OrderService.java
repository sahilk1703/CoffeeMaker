package edu.ncsu.csc.CoffeeMaker.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import edu.ncsu.csc.CoffeeMaker.customerOrder.CustomerOrders;
import edu.ncsu.csc.CoffeeMaker.repositories.OrderRepository;

/**
 * This class was implemented using Generative AI Service layer for managing
 * operations related to CustomerOrders.
 *
 * @author smuckra
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
@Component
@Transactional
public class OrderService extends Service<CustomerOrders, Long> {

    /**
     * Injected repository for accessing and managing order data in the
     * database.
     */
    @Autowired
    private OrderRepository orderRepository;

    // public OrderService ( final OrderRepository orderRepository ) {
    // this.orderRepository = orderRepository;
    // }

    /**
     * Provides the repository handle to the superclass.
     */
    @Override
    public JpaRepository<CustomerOrders, Long> getRepository () {
        return orderRepository;
    }

    /**
     * Retrieves all customer orders from the database.
     *
     * @return orderRepository.findAll() return all the orders
     */
    public List<CustomerOrders> findAllOrders () {
        return orderRepository.findAll();
    }

    /**
     * Finds all orders by their status.
     *
     * @param status
     *            the status to filter orders by.
     *
     * @return orderRepository.findOrderByStatus( status ) status of the order
     *         you are searching for
     */
    public List<CustomerOrders> findOrdersByStatus ( final String status ) {
        return orderRepository.findOrderByStatus( status );
    }

    /**
     * Marks an order as ready for pickup based on the order ID.
     *
     * @param orderId
     *            the ID of the order to update.
     * @return the updated order, or null if the order doesn't exist.
     */
    public CustomerOrders fulfillCustomerOrder ( final Long orderId ) {
        final Optional<CustomerOrders> customerOrder = orderRepository.findById( orderId );
        if ( customerOrder.isPresent() ) {
            final CustomerOrders existingOrder = customerOrder.get();
            existingOrder.updateStatus( CustomerOrders.READY_FOR_PICKUP );
            return orderRepository.save( existingOrder );
        }
        return null;
    }

    /**
     * Notifies that an order is ready for pickup by updating its status.
     *
     * @param orderId
     *            the ID of the order to update.
     */
    public void notifyOrderFulfillment ( final Long orderId ) {
        final Optional<CustomerOrders> customerOrder = orderRepository.findById( orderId );
        customerOrder.ifPresent( o -> {
            o.updateStatus( CustomerOrders.READY_FOR_PICKUP );
            orderRepository.save( o );
        } );
    }

    /**
     * Updates the status of an order.
     *
     * @param orderId
     *            the ID of the order to update.
     * @param newStatus
     *            the new status to set.
     *
     */
    public void updateOrderStatus ( final Long orderId, final String newStatus ) {
        final Optional<CustomerOrders> customerOrder = orderRepository.findById( orderId );
        customerOrder.ifPresent( o -> {
            o.updateStatus( newStatus );
            orderRepository.save( o );
        } );
    }

    /**
     * Finds orders by ID and status.
     *
     * @param parsedUserId
     *            the user ID of the order.
     * @param orderStatus
     *            the status of the order.
     *
     * @return ordersById the list of customer orders
     */
    public List<CustomerOrders> findByIdAndStatus ( final Long parsedUserId, final String orderStatus ) {
        final List<CustomerOrders> ordersById = new ArrayList<CustomerOrders>();
        if ( findOrdersByStatus( orderStatus ).size() == 0 ) {
            return ordersById;
        }
        for ( final CustomerOrders o : findOrdersByStatus( orderStatus ) ) {
            if ( o.getUserId().equals( parsedUserId ) ) {
                ordersById.add( o );
            }
        }
        return ordersById;
    }

    /**
     * Returns a count of the number of records of a given type stored in the
     * database. This is faster than, and should be preferred to,
     * `findAll().size()` if you don't care about the actual records themselves.
     *
     * @return The number of records in the DB.
     */
    @Override
    public long count () {
        return orderRepository.count();
    }
}
