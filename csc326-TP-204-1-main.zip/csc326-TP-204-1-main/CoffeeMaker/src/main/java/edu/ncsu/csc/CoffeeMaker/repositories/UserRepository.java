package edu.ncsu.csc.CoffeeMaker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * UserRepository is used to provide CRUD operations for the User model. Spring
 * will generate appropriate code with JPA.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 * @author Aranya Venugopal
 * @author Sahil Kanchan
 * @author Rishi Kamani
 *
 */
public interface UserRepository extends JpaRepository<User, Long> {
    /**
     * Finds a User object with the provided name. Spring will generate code to
     * make this happen.
     *
     * @param username
     *            username of the user
     * @return Found user, null if none.
     */
    User findByUsername ( String username );

    /**
     * Finds a user by their first name.
     * 
     * @param firstName First name to search for.
     * @return User if found, null otherwise.
     */
    User findByFirstName ( String firstName );

}
