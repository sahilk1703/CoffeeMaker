package edu.ncsu.csc.CoffeeMaker.security;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

import edu.ncsu.csc.CoffeeMaker.services.UserService;

/**
 * Generative AI was used for this code
 */
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * The private instance of UserService
     */
    @Autowired
    private UserService userService;

    /**
     * Authentication provider used to provide authentication
     *
     * @return provider the authentication provider
     */
    @Bean
    AuthenticationProvider authenticationProvider () {
        final DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService( userService );
        provider.setPasswordEncoder( new BCryptPasswordEncoder() );
        return provider;
    }

    /**
     * Configure method is used to give access to certain html files or
     * endpoints without authentication
     *
     * @param http
     *            the http request
     * @throws Exception
     *             any exceptions found
     */
    @Override
    protected void configure ( final HttpSecurity http ) throws Exception {
        http.csrf().disable().authorizeRequests()
                .antMatchers( "/", "/createAccount", "/createAccount.html", "/api/v1/signup", "/api/v1/login",
                        "/privacy_policy" )
                .permitAll().antMatchers( "/index_customer", "/index_customer.html" ).hasAuthority( "Customer" )
                .antMatchers( "/index", "/index.html", "/recipe", "/recipe.html", "/deleterecipe", "deleterecipe.html",
                        "/deleteIngredient.html", "/deleteIngredient", "/addIngredient.html", "/addIngredient",
                        "/editrecipe", "/editrecipe.html", "/makecoffee", "/makecoffee.html" )
                .hasAuthority( "Staff" )
                .antMatchers( "/index_manager", "/index_manager.html", "/inventory.html", "/inventory", "/ingredient",
                        "/ingredient.html" )
                .hasAuthority( "Manager" ).antMatchers( "/api/v1/makecoffee/{name}" ).permitAll().anyRequest()
                .authenticated().and().formLogin().loginPage( "/loginPage" )
                .successHandler( authenticationSuccessHandler() ) // Custom
                                                                  // success
                                                                  // handler
                .permitAll().and().logout().permitAll().and().httpBasic();

    }

    /**
     * Password encoder used to encode passwords
     *
     * @return The encrypted password
     */
    @Bean
    public PasswordEncoder passwordEncoder () {
        return new BCryptPasswordEncoder();
    }

    /**
     * Authentication success handler used to check for redirects
     *
     * @return the webpage to route to
     */
    @Bean
    public AuthenticationSuccessHandler authenticationSuccessHandler () {
        return new SimpleUrlAuthenticationSuccessHandler() {
            @Override
            protected String determineTargetUrl ( final HttpServletRequest request,
                    final HttpServletResponse response ) {
                // Get the current user's authorities
                final Collection< ? extends GrantedAuthority> authorities = SecurityContextHolder.getContext()
                        .getAuthentication().getAuthorities();
                // Check if the user has the "Customer" role
                if ( authorities.stream().anyMatch( a -> a.getAuthority().equals( "Customer" ) ) ) {
                    return "/index_customer"; // Redirect to the customer page
                }
                else if ( authorities.stream().anyMatch( a -> a.getAuthority().equals( "Staff" ) ) ) {
                    return "/index_staff"; // Redirect to the staff page
                }
                else if ( authorities.stream().anyMatch( a -> a.getAuthority().equals( "Manager" ) ) ) {
                    return "/index_manager"; // Redirect to the staff page
                }
                else {
                    return "/"; // Redirect to the default page if no role is
                                // found
                }
            }
        };
    }
}
