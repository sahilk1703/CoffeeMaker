package edu.ncsu.csc.CoffeeMaker.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import edu.ncsu.csc.CoffeeMaker.repositories.UserRepository;
import edu.ncsu.csc.CoffeeMaker.security.CustomerUserDetails;
import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 *
 * Service for user management and authentication within the Coffee Maker
 * application. Implements Spring Security's UserDetailsService for integration
 * with Spring Security.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
@Component
@Transactional
public class UserService implements UserDetailsService {

    /** Variable for password encoder */
    @Autowired
    private PasswordEncoder passwordEncoder;

    /** User service variable */
    @Autowired
    private UserService     userService;

    /** User repository variable */
    @Autowired
    private UserRepository  userRepository;

    /**
     *
     * Provides access to the underlying user repository.
     *
     * @return A JpaRepository instance for User entities.
     */
    protected JpaRepository<User, Long> getRepository () {

        return userRepository;
    }

    /**
     * Authenticates a user based on username and password.
     *
     * @param username
     *            The username of the user.
     * @param password
     *            The password of the user.
     * @return true if authentication is successful, false otherwise.
     */
    public boolean authenticate ( final String username, final String password ) {
        final User user = userRepository.findByUsername( username );
        if ( user != null && passwordEncoder.matches( password, user.getPassword() ) ) {
            return true;
        }
        return false;
    }

    /**
     * Loads the user details by username. Required by Spring Security's
     * UserDetailsService.
     *
     * @param username
     *            The username of the user to load.
     * @return UserDetails containing information of the loaded user.
     * @throws UsernameNotFoundException
     *             If the username is not found.
     */
    @Override
    public UserDetails loadUserByUsername ( final String username ) throws UsernameNotFoundException {
        final User user = userRepository.findByUsername( username );
        if ( user == null ) {
            throw new UsernameNotFoundException( "User Not Found" );
        }
        return new CustomerUserDetails( user );
    }

    /**
     * This method finds the name given in the parameter by finding it in the
     * user repository
     * 
     * @param name
     *            name to be found in the user repository
     * @return userRepository.findByFirstName(name) the user object of the name
     *         found
     */
    public User findByName ( final String name ) {
        return userRepository.findByFirstName( name );
    }

    /**
     * Saves a user to the repository, with password encryption.
     *
     * @param user
     *            The user to save.
     */
    public void saveUser ( final User user ) {
        // Encrypt the password
        user.setPassword( passwordEncoder.encode( user.getPassword() ) );
        // Save user
        userService.save( user );
    }

    /**
     * Provides a bean of UserDetailsService to be used by the application.
     *
     * @return An instance of UserDetailsService.
     */
    @Bean
    public UserDetailsService userDetailsService () {
        return userService;
    }

    /**
     * Saves the provided object into the database. If the object already
     * exists, `save()` will perform an in-place update, overwriting the
     * existing record.
     *
     * @param obj
     *            The object to save into the database.
     */
    public void save ( final User obj ) {
        getRepository().saveAndFlush( obj );
    }

    /**
     * Returns all records of this type that exist in the database. If you want
     * more precise ways of retrieving an individual record (or collection of
     * records) see `findBy(Example)`
     *
     * @return All records stored in the database.
     */
    public List<User> findAll () {
        return getRepository().findAll();
    }

    /**
     * Saves a collection of elements to the database. If an error occurs saving
     * any of them, no objects will be saved. This makes it handy for ensuring
     * database consistency where all records should exist together.
     *
     * @param objects
     *            A List of objects to save to the database.
     */
    public void saveAll ( final List<User> objects ) {
        getRepository().saveAll( objects );
        getRepository().flush();
    }

    /**
     * Deletes an object from the database. This will remove the object from the
     * database, but not from memory. Trying to save it again after deletion is
     * undefined behaviour. YMMV.
     *
     * @param obj
     *            The object to delete from the database.
     */
    public void delete ( final User obj ) {
        getRepository().delete( obj );
    }

    /**
     * Removes all records of a given type from the database. For example,
     * `UserService.deleteAll()` would delete all Users. Be very careful when
     * calling this.
     */
    public void deleteAll () {
        getRepository().deleteAll();
    }

    /**
     * Returns a count of the number of records of a given type stored in the
     * database. This is faster than, and should be preferred to,
     * `findAll().size()` if you don't care about the actual records themselves.
     *
     * @return The number of records in the DB.
     */
    public long count () {
        return getRepository().count();
    }

}
