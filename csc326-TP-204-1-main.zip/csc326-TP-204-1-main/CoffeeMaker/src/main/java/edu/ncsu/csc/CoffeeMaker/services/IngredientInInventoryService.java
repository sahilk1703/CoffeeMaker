package edu.ncsu.csc.CoffeeMaker.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.repositories.IngredientInInventoryRepository;

/**
 * The IngredientInInventoryService is used to handle CRUD operations on the
 * Ingredient model. All of these functionalities represent those from
 * 'Service'.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@Component
@Transactional
public class IngredientInInventoryService extends Service<IngredientInInventory, Long> {

    /**
     * IngredientInInventoryRepository, to be autowired in by Spring and provide
     * CRUD operations on the IngredientInInventory model
     */
    @Autowired
    private IngredientInInventoryRepository inventoryIngredientRepository;

    /**
     * Returns the instance of the ingredientInInventoryRepository
     *
     * @return instance of the inventoryIngredientRepository
     */
    @Override
    protected JpaRepository<IngredientInInventory, Long> getRepository () {
        return inventoryIngredientRepository;
    }

}
