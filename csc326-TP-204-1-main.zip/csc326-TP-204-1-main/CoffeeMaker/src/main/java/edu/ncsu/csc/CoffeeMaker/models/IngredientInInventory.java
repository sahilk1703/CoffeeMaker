package edu.ncsu.csc.CoffeeMaker.models;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * IngredientInInventory for the coffee maker. IngredientInInventory is tied to
 * the database using Hibernate libraries. See IngredientInInventoryRepository
 * and IngredientInInventoryService for the other two pieces used for database
 * support.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 *
 */

@Entity
public class IngredientInInventory extends DomainObject {

    /** Ingredient id */
    @Id
    @GeneratedValue
    Long    id;

    /** Type of Ingredient */
    String  name;

    /** Amount of Ingredient */
    Integer inventoryAmount;

    /**
     * Creates a default ingredient for the coffee maker
     */
    public IngredientInInventory () {

    }

    /**
     * Creates a ingredientInInventory object with the given name and amount for
     * the coffee maker
     *
     * @param name
     *            for the type of the ingredient
     * @param inventoryAmount
     *            for the initial amount of the ingredient
     */
    public IngredientInInventory ( final String name, final Integer inventoryAmount ) {
        setName( name );
        setInventoryAmount( inventoryAmount );
    }

    /**
     * Returns the type of ingredient
     *
     * @return the ingredient type
     */
    public String getName () {
        return name;
    }

    /**
     * Sets the type of ingredient
     *
     * @param name
     *            the ingredient to set
     */
    public void setName ( final String name ) {
        this.name = name;
    }

    /**
     * Returns the initial amount of ingredient in inventory
     *
     * @return the amount for the initial amount of the ingredient
     */
    public Integer getInventoryAmount () {

        return inventoryAmount;
    }

    /**
     * Sets the initial amount of the ingredient in inventory
     *
     * @param inventoryAmount
     *            the amount to set
     * @throws IllegalArgumentException
     *             for invalid price ( negative value ) of the ingredient
     */
    public void setInventoryAmount ( final Integer inventoryAmount ) {
        if ( inventoryAmount < 0 ) {
            throw new IllegalArgumentException( "Invalid units." );
        }
        this.inventoryAmount = inventoryAmount;
    }

    /**
     * Returns the ingredients with its id and initial amount in string format
     */
    @Override
    public String toString () {
        return "InventoryIngredient [id=" + id + ", name=" + name + ", inventoryAmount=" + inventoryAmount + "]";
    }

    /**
     * Sets the id of the ingredient
     *
     * @param id
     *            the id to set
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Returns the ID of the entry in the DB
     *
     * @return id for the id of the ingredient
     */
    @Override
    public Serializable getId () {
        return id;
    }
}
