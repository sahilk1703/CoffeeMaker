package edu.ncsu.csc.CoffeeMaker.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Controller class for the URL mappings for CoffeeMaker. The controller returns
 * the approprate HTML page in the /src/main/resources/templates folder. For a
 * larger application, this should be split across multiple controllers.
 *
 * @author Kai Presler-Marshall
 */
@Controller
public class MappingController {

    /**
     * On a GET request to /index, the IndexController will return
     * /src/main/resources/templates/index.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/loginPage", "/" } )
    public String index ( final Model model ) {
        return "loginPage";
    }

    /**
     * On a GET request to /recipe, the RecipeController will return
     * /src/main/resources/templates/recipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/recipe", "/recipe.html" } )
    public String addRecipePage ( final Model model ) {
        return "recipe";
    }

    /**
     * On a GET request to /ingredient, the IngredientController will return
     * /src/main/resources/templates/ingredient.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/ingredient", "/ingredient.html" } )
    public String addIngredientPage ( final Model model ) {
        return "ingredient";
    }

    /**
     * On a GET request to /ingredient, the APIController will return
     * /src/main/resources/templates/index.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/index_staff", "/index_staff.html" } )
    public String indexStaffForm ( final Model model ) {
        return "index_staff";
    }

    /**
     * On a GET request to /deleterecipe, the DeleteRecipeController will return
     * /src/main/resources/templates/deleterecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/deleterecipe", "/deleterecipe.html" } )
    public String deleteRecipeForm ( final Model model ) {
        return "deleterecipe";
    }

    /**
     * On a GET request to /deleteIngredient, the DeleteIngredientController
     * will return /src/main/resources/templates/deleteIngredient.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/deleteIngredient", "/deleteIngredient.html" } )
    public String deleteIngredientForm ( final Model model ) {
        return "deleteIngredient";
    }

    /**
     * On a GET request to /addIngredient, AddIngredientController will return
     * /src/main/resources/templates/addIngredient.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/addIngredient", "/addIngredient.html" } )
    public String addIngredientForm ( final Model model ) {
        return "addIngredient";
    }

    /**
     * On a GET request to /editrecipe, the EditRecipeController will return
     * /src/main/resources/templates/editrecipe.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/editrecipe", "/editrecipe.html" } )
    public String editRecipeForm ( final Model model ) {
        return "editrecipe";
    }

    /**
     * Handles a GET request for inventory. The GET request provides a view to
     * the client that includes the list of the current ingredients in the
     * inventory and a form where the client can enter more ingredients to add
     * to the inventory.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/inventory", "/inventory.html" } )
    public String inventoryForm ( final Model model ) {
        return "inventory";
    }

    /**
     * On a GET request to /makecoffee, the MakeCoffeeController will return
     * /src/main/resources/templates/makecoffee.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/makecoffee", "/makecoffee.html" } )
    public String makeCoffeeForm ( final Model model ) {
        return "makecoffee";
    }

    /**
     * On a GET request to /createaccount, the MakeCoffeeController will return
     * /src/main/resources/templates/createAccount.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/createAccount", "/createAccount.html" } )
    public String createAccountForm ( final Model model ) {
        return "createAccount";
    }

    /**
     * On a GET request to /index_customer, the controller will return
     * /src/main/resources/templates/index_customer.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/index_customer", "/index_customer.html" } )
    public String indexCustomerForm ( final Model model ) {
        return "index_customer";
    }

    /**
     *
     * On a GET request to /index_customer, the controller will return
     * /src/main/resources/templates/index_customer.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/index_manager", "/index_manager.html" } )
    public String indexManagerForm ( final Model model ) {
        return "index_manager";

    }

    /**
     * Handles a GET request to /orderBeverage. This method returns the page for
     * ordering beverages, allowing users to select and order their choice of
     * beverage.
     *
     * @param model
     *            the model attribute to be passed to the view for rendering
     *            data
     * @return the name of the template to be rendered as the response
     */
    @GetMapping ( { "/orderBeverage", "/orderBeverage.html" } )
    public String orderBeverageForm ( final Model model ) {
        return "orderBeverage";
    }

    /**
     * Handles a GET request to /viewOrder. This method returns the page for
     * viewing placed orders, where users can check the status of their beverage
     * orders.
     *
     * @param model
     *            the model attribute to be passed to the view for rendering
     *            data
     * @return the name of the template to be rendered as the response
     */
    @GetMapping ( { "/viewOrder", "/viewOrder.html" } )
    public String viewOrderForm ( final Model model ) {
        return "viewOrder";
    }

    /**
     * Handles a GET request to /orderHistory_staff.html. This method returns
     * the page for viewing order history, where users can check their orders
     * and the status of all those others.
     *
     * @param model
     *            the model attribute to be passed to the view for rendering
     *            data
     * @return the name of the template to be rendered as the response
     */
    @GetMapping ( { "/orderHistory_staff", "/orderHistory_staff.html" } )
    public String orderHistoryStaffForm ( final Model model ) {
        return "orderHistory_staff";
    }

    /**
     * Handles a GET request to /orderHistory_manager.html. This method returns
     * the page for viewing order history, where users can check their orders
     * and the status of all those others.
     *
     * @param model
     *            the model attribute to be passed to the view for rendering
     *            data
     * @return the name of the template to be rendered as the response
     */
    @GetMapping ( { "/orderHistory_manager", "/orderHistory_manager.html" } )
    public String orderHistoryManagerForm ( final Model model ) {
        return "orderHistory_manager";
    }

    /**
     * On a GET request to /privacy_policy, will return
     * /src/main/resources/templates/privacy_policy.html.
     *
     * @param model
     *            underlying UI model
     * @return contents of the page
     */
    @GetMapping ( { "/privacy_policy", "/privacy_policy.html" } )
    public String privacyPolicyForm ( final Model model ) {
        return "privacy_policy";
    }

}
