package edu.ncsu.csc.CoffeeMaker.security;

import java.util.Collection;
import java.util.Collections;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * This class is responsible for holding the user detail information of a given
 * user - a staff or customer.
 *
 * Generative AI was used for this code
 *
 * @author Shazia Muckram
 * @author Satwika Kancharla
 * @author Sahil Kanchan
 * @author Rishima Kadhav
 * @author Rishi Kamani
 * @author Aranya Venugopal
 */
public class CustomerUserDetails implements UserDetails {

    /** Represents the user object **/
    private final User user;

    /**
     * This constructor is responsible for initializing the user object
     *
     * @param user
     *            refers to the user
     */
    public CustomerUserDetails ( final User user ) {
        super();
        this.user = user;
    }

    /**
     * This method is responsible for communicating with spring security with
     * role information and associated authority information
     */
    @Override
    public Collection< ? extends GrantedAuthority> getAuthorities () {
        return Collections.singleton( new SimpleGrantedAuthority( user.getRole() ) );
    }

    @Override
    public String getPassword () {
        return user.getPassword();
    }

    @Override
    public String getUsername () {
        return user.getusername();
    }

    @Override
    public boolean isAccountNonExpired () {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isAccountNonLocked () {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired () {
        // TODO Auto-generated method stub
        return true;
    }

    @Override
    public boolean isEnabled () {
        // TODO Auto-generated method stub
        return true;
    }

}
