package edu.ncsu.csc.CoffeeMaker.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;

/**
 * Recipe for the coffee maker. Recipe is tied to the database using Hibernate
 * libraries. See RecipeRepository and RecipeService for the other two pieces
 * used for database support.
 *
 * @author Kai Presler-Marshall
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@Entity
public class Recipe extends DomainObject {

    /** Recipe id */
    @Id
    @GeneratedValue
    private Long                   id;

    /** Recipe name */
    private String                 name;

    /** Recipe price */
    @Min ( 0 )
    private Integer                price;

    /** For the list of the ingredients in the recipe */
    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private final List<Ingredient> ingredients;

    /**
     * Creates a default recipe for the coffee maker.
     */
    public Recipe () {
        this.name = "";
        ingredients = new ArrayList<Ingredient>();
    }

    /**
     * Method to check if the ingredient is present in the recipe.
     *
     * @param ingredient
     *            for the ingredient to be checked
     * @return true if the ingredient is present in the recipe; false if the
     *         ingredient is not present
     */
    private boolean containName ( final Ingredient ingredient ) {
        for ( int i = 0; i < ingredients.size(); i++ ) {
            if ( ingredients.get( i ).getName().equals( ingredient.getName() ) ) {
                return true;
            }
        }
        return false;

    }

    /**
     * Add the ingredient in the recipe
     *
     * @param ingredient
     *            for the ingredient to be added in the recipe
     */
    public void addIngredient ( final Ingredient ingredient ) {

        if ( !containName( ingredient ) ) {
            ingredients.add( ingredient );
        }
        // else {
        // throw new IllegalArgumentException( "Ingredient cannot be added" );
        // }

    }

    /**
     * Returns the list of ingredients in the recipe
     *
     * @return ingredients for the ingredients in the recipe
     */
    public List<Ingredient> getIngredients () {
        return ingredients;
    }

    /**
     * Check if the price is positive
     *
     * @return true if all ingredient fields are 0, otherwise return false
     */
    public boolean checkRecipe () {
        if ( price < 0 ) {
            return false;
        }
        return true;
    }

    /**
     * Get the ID of the Recipe
     *
     * @return the ID
     */
    @Override
    public Long getId () {
        return id;
    }

    /**
     * Set the ID of the Recipe (Used by Hibernate)
     *
     * @param id
     *            the ID
     */
    @SuppressWarnings ( "unused" )
    private void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Returns name of the recipe.
     *
     * @return Returns the name.
     */
    public String getName () {
        return name;
    }

    /**
     * Sets the recipe name.
     *
     * @param name
     *            The name to set.
     */
    public void setName ( final String name ) {
        this.name = name;
    }

    /**
     * Returns the price of the recipe.
     *
     * @return Returns the price.
     */
    public Integer getPrice () {
        return price;
    }

    /**
     * Sets the recipe price.
     *
     * @param price
     *            The price to set.
     */
    public void setPrice ( final Integer price ) {
        this.price = price;
    }

    /**
     * Return the ingredient with the given name
     *
     * @param name
     *            for the name of the ingredient to be returned
     * @return ingredient with the given name; null if the ingredient does not
     *         exist
     */
    public Ingredient getIngredient ( final String name ) {

        for ( int i = 0; i < ingredients.size(); i++ ) {
            if ( ingredients.get( i ).getName().equals( name ) ) {
                return ingredients.get( i );
            }
        }
        return null;
    }

    /**
     * Updates the fields to be equal to the passed Recipe by editing the price,
     * removing ingredients, and adding ingredients
     *
     * @param r
     *            recipe with updated fields, both price and ingredients
     */
    public void updateRecipe ( final Recipe r ) {
        if ( r.getIngredients().size() == 0 ) {
            throw new IllegalArgumentException( "No ingredients added." );
        }
        if ( r.checkRecipe() ) {
            setPrice( r.getPrice() );
        }
        else {
            throw new IllegalArgumentException( "Invalid price." );
        }
        if ( r.getIngredients().size() > ingredients.size() ) {
            for ( int i = ingredients.size(); i < r.getIngredients().size(); i++ ) {
                addIngredient( r.getIngredients().get( i ) );
            }
        }
        else {
            for ( int i = 0; i < r.getIngredients().size(); i++ ) {
                if ( ingredients.get( i ).getAmount() != r.getIngredients().get( i ).getAmount() ) {
                    editQuantity( r.getIngredients().get( i ).getName(), r.getIngredients().get( i ).getAmount() );
                }
            }
        }
    }

    /**
     * Edits the quantity of the ingredient with the given name to the updated
     * quantity. If the updated quantity is 0, it removes the ingredient from
     * the list of ingredients
     *
     * @param name
     *            name of the ingredient
     * @param quantity
     *            updated quantity for the ingredient
     */
    public void editQuantity ( final String name, final int quantity ) {
        if ( quantity == 0 ) {
            removeIngredient( name );
        }
        else {
            final Ingredient ingredient = getIngredient( name );
            ingredient.setAmount( quantity );
        }
    }

    /**
     * Removes the given ingredient from the recipe. If there is only one
     * ingredient in the recipe, it throws an error message.
     *
     * @param name
     *            name of the ingredient to be removed
     * @throws IllegalArgumentException
     *             if there is only one ingredient and attempting to remove that
     */
    public void removeIngredient ( final String name ) {
        final Ingredient ingredient = getIngredient( name );
        if ( ingredients.size() == 1 ) {
            throw new IllegalArgumentException( "No ingredients added." );
        }
        ingredients.remove( ingredient );
    }

    /**
     * Returns the name of the recipe.
     *
     * @return String
     */
    @Override
    public String toString () {
        final String str = name + "\n" + ingredients.toString();
        return str;

    }

    /**
     * Generates the hash code
     *
     * @return hashcode
     */
    @Override
    public int hashCode () {
        final int prime = 31;
        Integer result = 1;
        result = prime * result + ( ( name == null ) ? 0 : name.hashCode() );
        return result;
    }

    /**
     * Checks if the objects are equal
     *
     * @return true if they are equal and false otherwise
     */
    @Override
    public boolean equals ( final Object obj ) {
        if ( this == obj ) {
            return true;
        }
        if ( obj == null ) {
            return false;
        }
        if ( getClass() != obj.getClass() ) {
            return false;
        }
        final Recipe other = (Recipe) obj;
        if ( name == null ) {
            if ( other.name != null ) {
                return false;
            }
        }
        else if ( !name.equals( other.name ) ) {
            return false;
        }
        return true;
    }

}
