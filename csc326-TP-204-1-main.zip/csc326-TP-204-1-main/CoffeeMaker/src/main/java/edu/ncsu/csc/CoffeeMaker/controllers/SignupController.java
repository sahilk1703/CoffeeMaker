package edu.ncsu.csc.CoffeeMaker.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.CoffeeMaker.services.UserService;
import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * SignupController has the API Endpoints to sign people up
 */
@RestController
public class SignupController extends APIController {

    /**
     * Private instance of UserService
     */
    @Autowired
    private UserService userService;

    /**
     * Signup is the api endpoint for signing up
     *
     * @param newUser
     *            the user object
     * @return a response entity from the front end.
     */
    @SuppressWarnings ( { "unchecked", "rawtypes" } )
    @PostMapping ( BASE_PATH + "signup" )
    public ResponseEntity signup ( @RequestBody final User newUser ) {
        System.out.print( "HERE" );
        try {
            userService.saveUser( newUser );
            // You may want to log the success or send a more detailed response
            return new ResponseEntity( successResponse( " Account has been was created successfully" ), HttpStatus.OK );
            // return ResponseEntity.status( HttpStatus.OK ).body( "Account has
            // been created successfully." );
        }
        catch ( final IllegalArgumentException e ) {
            // Catch known exceptions and return meaningful message
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.BAD_REQUEST );
        }
        catch ( final Exception e ) {
            // Log the exception as it's unexpected and return a generic error
            // message
            // Log.error("Unexpected error during signup", e);
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.INTERNAL_SERVER_ERROR );

        }
    }
}
