package edu.ncsu.csc.CoffeeMaker.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

/**
 * Inventory for the coffee maker. Inventory is tied to the database using
 * Hibernate libraries. See InventoryRepository and InventoryService for the
 * other two pieces used for database support.
 *
 * @author Kai Presler-Marshall
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@Entity
public class Inventory extends DomainObject {

    /** id for inventory entry */
    @Id
    @GeneratedValue
    private Long                              id;

    /** List of ingredients in Inventory */
    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private final List<IngredientInInventory> ingredients;

    /**
     * Creates a new list of IngredientInInventory
     */
    public Inventory () {
        ingredients = new ArrayList<IngredientInInventory>();
    }

    /**
     * Creates inventory with given ingredient
     *
     * @param ingredient1
     *            for the ingredient to be added in the ingredient
     */
    public Inventory ( final IngredientInInventory ingredient1 ) {
        ingredients = new ArrayList<IngredientInInventory>();
        ingredients.add( ingredient1 );
    }

    /**
     * Returns the ID of the entry in the DB
     *
     * @return id for the id of the inventory
     */
    @Override
    public Long getId () {
        return id;
    }

    /**
     * Set the ID of the Inventory (Used by Hibernate)
     *
     * @param id
     *            the ID
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Checks if the amount of the ingredient is valid amount (non-negative
     * amount)
     *
     * @param amount
     *            for the ingredient to be added
     * @throws IllegalArgumentException
     *             if the parameter isn't a positive integer
     * @return amtIngredient if the amount is valid amount;
     *         IllegalArgumentException if invalid amount
     */
    public Integer checkIngredient ( final String amount ) throws IllegalArgumentException {
        Integer amtIngredient = 0;
        try {
            amtIngredient = Integer.parseInt( amount );
        }
        catch ( final NumberFormatException e ) {
            throw new IllegalArgumentException( "Units of ingredient must be a positive integer" );
        }
        if ( amtIngredient < 0 ) {
            throw new IllegalArgumentException( "Units of ingredient must be a positive integer" );
        }

        return amtIngredient;
    }

    /**
     * Returns true if there are enough ingredients to make the beverage.
     *
     * @param r
     *            recipe to check if there are enough ingredients
     * @return true if enough ingredients to make the beverage
     */
    public boolean enoughIngredients ( final Recipe r ) {

        for ( int i = 0; i < r.getIngredients().size(); i++ ) {
            if ( containName( r.getIngredients().get( i ) ) ) {
                for ( int j = 0; j < r.getIngredients().size(); j++ ) {
                    if ( ingredients.get( i ).getName().equals( r.getIngredients().get( j ).getName() )
                            && ingredients.get( i ).getInventoryAmount() < r.getIngredients().get( j ).getAmount() ) {

                        return false;
                    }
                }
            }

        }
        return true;
    }

    /**
     * Checks if the ingredients is present in the inventory
     *
     * @param ingredient
     *            for ingredient that needs to be checked
     * @return true if the ingredient is present in the inventory; false if the
     *         ingredient is not present in the inventory
     */
    public boolean containName ( final Ingredient ingredient ) {
        for ( int i = 0; i < ingredients.size(); i++ ) {
            if ( ingredients.get( i ).getName().equals( ingredient.getName() ) ) {
                return true;
            }
        }
        return false;

    }

    /**
     * Removes the ingredients used to make the specified recipe. Assumes that
     * the user has checked that there are enough ingredients to make
     *
     * @param r
     *            recipe to make
     * @return true if recipe is made.
     */
    public boolean useIngredients ( final Recipe r ) {
        if ( enoughIngredients( r ) ) {

            for ( int i = 0; i < r.getIngredients().size(); i++ ) {
                if ( containName( r.getIngredients().get( i ) ) ) {
                    for ( int j = 0; j < ingredients.size(); j++ ) {
                        if ( ingredients.get( j ).getName().equals( r.getIngredients().get( i ).getName() ) ) {
                            ingredients.get( j ).setInventoryAmount( ingredients.get( j ).getInventoryAmount()
                                    - r.getIngredients().get( i ).getAmount() );
                        }
                    }
                }

            }
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Adds ingredients to the inventory
     *
     * @param ingredient
     *            amt of ingredient
     * @return true if ingredient was successfully added, false if not added in
     *         the inventory
     */
    public boolean addIngredient ( final IngredientInInventory ingredient ) {

        if ( ingredient == null ) {
            throw new IllegalArgumentException( "Invalid ingredient" );
        }
        boolean flag = false;
        int idx = -1;
        for ( int j = 0; j < ingredients.size(); j++ ) {
            if ( ingredients.get( j ).getName().equals( ingredient.getName() ) ) {
                flag = true;
                idx = j;
                break;
            }

        }
        if ( flag ) {
            if ( ingredient.getInventoryAmount() == 0 ) {
                ingredients.get( idx ).setInventoryAmount( 0 );
            }
            else {
                ingredients.get( idx ).setInventoryAmount(
                        ingredients.get( idx ).getInventoryAmount() + ingredient.getInventoryAmount() );
            }

        }

        else {
            ingredients.add( ingredient );
        }

        return true;
    }

    /**
     * Return the list of ingredients in the inventory
     *
     * @return ingredients for the list of ingredients in the inventory
     */
    public List<IngredientInInventory> getIngredients () {
        return ingredients;
    }

    /**
     * Returns the ingredient with the given ingredient
     *
     * @param name
     *            for the name of the ingredient
     * @return ingredient if the ingredient is present in the inventory; null if
     *         the ingredients are not present in the inventory
     */
    public IngredientInInventory getIngredient ( final String name ) {

        for ( int i = 0; i < ingredients.size(); i++ ) {
            if ( ingredients.get( i ).getName().equals( name ) ) {
                return ingredients.get( i );
            }
        }
        return null;
    }

    /**
     * Returns list of ingredients and respective amount present in the
     * inventory
     *
     * @return the list of ingredients as a string
     */
    @Override
    public String toString () {
        String str = "";
        for ( int i = 0; i < ingredients.size(); i++ ) {
            str += ingredients.get( i ).getName() + ": " + ingredients.get( i ).getInventoryAmount() + "\n";
        }
        return str;
    }

}
