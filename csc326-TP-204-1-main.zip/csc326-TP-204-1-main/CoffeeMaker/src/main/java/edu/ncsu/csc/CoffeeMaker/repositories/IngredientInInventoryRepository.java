package edu.ncsu.csc.CoffeeMaker.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;

/**
 * IngredientInInventoryRepository is used to provide CRUD operations for the
 * IngredientInInventory model. Spring will generate appropriate code with JPA.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
public interface IngredientInInventoryRepository extends JpaRepository<IngredientInInventory, Long> {

}
