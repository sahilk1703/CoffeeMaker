package edu.ncsu.csc.CoffeeMaker.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.CoffeeMaker.customerOrder.CustomerOrders;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.OrderService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;
import edu.ncsu.csc.CoffeeMaker.services.UserService;
import edu.ncsu.csc.CoffeeMaker.users.User;

/**
 * REST controller for managing coffee orders. Handles web requests related to
 * coffee orders and dispatches them to the OrderService.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
@SuppressWarnings ( { "unchecked", "rawtypes" } )
@RestController
public class APIOrderController extends APIController {

    /**
     * Service for order-related operations.
     */
    @Autowired
    private OrderService        service;

    /**
     * Service for recipe-related operations.
     */
    @Autowired
    private RecipeService       recipeService;

    /**
     * Service for user-related operations.
     */
    @Autowired
    private UserService         userService;

    /**
     * Controller for coffee-making actions.
     */
    @Autowired
    private APICoffeeController controller;

    /**
     * Fetches orders based on user ID and order status.
     *
     * @param userName
     *            The user name associated with the orders.
     * @param orderStatus
     *            The status of the orders to fetch.
     * @return A list of orders matching the criteria.
     */
    @GetMapping ( BASE_PATH + "orders/{userName}/{orderStatus}" )
    public List<CustomerOrders> getOrderByIdAndStatus ( @PathVariable ( "userName" ) final String userName,
            @PathVariable ( "orderStatus" ) final String orderStatus ) {
        final User u = userService.findByName( userName );

        return service.findByIdAndStatus( u.getId(), orderStatus );
    }

    /**
     * Fetches orders by their status.
     *
     * @param orderStatus
     *            The status of the orders to retrieve.
     * @return A list of orders with the specified status.
     */
    @GetMapping ( BASE_PATH + "orders/status/{orderStatus}" )
    public List<CustomerOrders> getOrderByStatus ( @PathVariable ( "orderStatus" ) final String orderStatus ) {
        return service.findOrdersByStatus( orderStatus );
    }

    /**
     * Retrieves a specific order by ID.
     *
     * @param orderId
     *            The ID of the order to retrieve.
     * @return A ResponseEntity containing the order or an error message.
     */
    @GetMapping ( BASE_PATH + "orders/{orderId}" )
    public ResponseEntity getOrderById ( @PathVariable ( "orderId" ) final String orderId ) {
        final Long parsedOrderId = Long.parseLong( orderId );

        final CustomerOrders order = service.findById( parsedOrderId );
        return null == order
                ? new ResponseEntity( errorResponse( "No order found with id " + orderId ), HttpStatus.NOT_FOUND )
                : new ResponseEntity( order, HttpStatus.OK );
    }

    /**
     * Retrieves all of the orders that have been placed.
     *
     * @return A ResponseEntity containing the list of all orders.
     */
    @GetMapping ( BASE_PATH + "orders" )
    public ResponseEntity getAllOrders () {
        final List<CustomerOrders> orders = service.findAllOrders();

        return new ResponseEntity( orders, HttpStatus.OK );
    }

    /**
     * Fulfills a specific order based on its ID by updating its status to
     * READY_FOR_PICKUP.
     *
     * @param orderId
     *            The ID of the order to fulfill.
     * @return A ResponseEntity indicating the result of the operation.
     */
    @PutMapping ( BASE_PATH + "orders/fulfill/{orderId}" )
    public ResponseEntity fulfillOrder ( @PathVariable ( "orderId" ) final String orderId ) {
        // reference to makeCoffee in APICoffeeController

        final Long parsedOrderId = Long.parseLong( orderId );
        final CustomerOrders order = service.findById( parsedOrderId );
        final ResponseEntity response = controller.makeCoffee( order.getRecipe().get( 0 ).getName(),
                order.getAmount() );

        if ( order.getId() == null ) {
            return new ResponseEntity( errorResponse( "No order found with id " + orderId ), HttpStatus.NOT_FOUND );
        }
        if ( response.getStatusCode().equals( HttpStatus.OK ) ) {
            order.setRemainingAmount( controller.makeCoffee( order.getRecipe().get( 0 ), order.getAmount() ) );
            order.updateStatus( CustomerOrders.READY_FOR_PICKUP );
        }
        else {
            order.updateStatus( CustomerOrders.CANCELLED_STATUS );
        }

        service.save( order );

        return response;
    }

    /**
     * Retrieves the status of a specific order by its ID.
     *
     * @param orderId
     *            The ID of the order whose status is to be checked.
     * @return containing the status of the order or an error message.
     */
    @GetMapping ( BASE_PATH + "orders/{orderId}/status" )
    public ResponseEntity getOrderStatus ( @PathVariable ( "orderId" ) final String orderId ) {
        final Long parsedOrderId = Long.parseLong( orderId );
        final CustomerOrders order = service.findById( parsedOrderId );
        return null == order
                ? new ResponseEntity( errorResponse( "No order found with id " + orderId ), HttpStatus.NOT_FOUND )
                : new ResponseEntity( order.getStatus(), HttpStatus.OK );
    }

    /**
     * Marks an order as picked up and updates its status to COMPLETED.
     *
     * @param orderId
     *            The ID of the order to update.
     * @return indicating the result of the update.
     */
    @PutMapping ( BASE_PATH + "orders/{orderId}" )
    public ResponseEntity pickupOrder ( @PathVariable ( "orderId" ) final String orderId ) {
        final Long parsedOrderId = Long.parseLong( orderId );
        final CustomerOrders order = service.findById( parsedOrderId );
        if ( order == null ) {
            return new ResponseEntity( errorResponse( "No order found with id " + orderId ), HttpStatus.NOT_FOUND );
        }

        order.updateStatus( CustomerOrders.COMPLETED );

        service.save( order );

        return new ResponseEntity( successResponse( "Order Completed" ), HttpStatus.OK );

    }

    /**
     * Creates a new order based on the provided recipe name, user name, and
     * amount.
     *
     * @param recipeName
     *            Name of the recipe to include in the order.
     * @param userName
     *            Name of the user placing the order.
     * @param amount
     *            Amount of the product ordered.
     * @return indicating the result of the operation.
     */
    @PostMapping ( BASE_PATH + "orders/{recipeName}/{userName}" )
    public ResponseEntity createOrder ( @PathVariable ( "recipeName" ) final String recipeName,
            @PathVariable ( "userName" ) final String userName, @RequestBody final int amount ) {
        final Recipe r = recipeService.findByName( recipeName );
        final User u = userService.findByName( userName );
        final List<Recipe> recipes = new ArrayList<Recipe>();
        recipes.add( r );
        try {
            final CustomerOrders order = new CustomerOrders( u.getId(), recipes, CustomerOrders.PENDING_STATUS, amount,
                    CustomerOrders.CUSTOMER_ROLE );
            service.save( order );
        }
        catch ( final Exception e ) {
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.BAD_REQUEST );
        }

        return new ResponseEntity( successResponse( "Order Created" ), HttpStatus.OK );

    }

    /**
     * Fetches the remaining change for the order
     *
     * @param orderId
     *            for the given order
     * @return the remaining change
     */
    @GetMapping ( BASE_PATH + "orders/{orderId}/remainingAmount" )
    public int getRemainingAmount ( @PathVariable ( "orderId" ) final String orderId ) {
        final Long parsedOrderId = Long.parseLong( orderId );
        final CustomerOrders order = service.findById( parsedOrderId );

        return order.getRemainingAmount();
    }

}
