package edu.ncsu.csc.CoffeeMaker.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.models.IngredientInInventory;
import edu.ncsu.csc.CoffeeMaker.models.Inventory;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;
import edu.ncsu.csc.CoffeeMaker.services.IngredientService;
import edu.ncsu.csc.CoffeeMaker.services.InventoryService;
import edu.ncsu.csc.CoffeeMaker.services.RecipeService;

/**
 * This is the controller that holds the REST endpoints that handle CRUD
 * operations for Recipes.
 *
 * Spring will automatically convert all of the ResponseEntity and List results
 * to JSON
 *
 * @author Kai Presler-Marshall
 * @author Michelle Lemons
 *
 */
@SuppressWarnings ( { "unchecked", "rawtypes" } )
@RestController
public class APIRecipeController extends APIController {

    /**
     * RecipeService object, to be autowired in by Spring to allow for
     * manipulating the Recipe model
     */
    @Autowired
    private RecipeService     service;

    /**
     * InventoryService object, to be autowired in by Spring to allow for
     * manipulating the Inventory model
     */
    @Autowired
    private InventoryService  ivt;

    /**
     * IngredientService object, to be autorwired in by Spring to allow for
     * manipulating the Ingredient model
     */
    @Autowired
    private IngredientService iService;

    /**
     * REST API method to provide GET access to all recipes in the system
     *
     * @return JSON representation of all recipies
     */
    @GetMapping ( BASE_PATH + "/recipes" )
    public List<Recipe> getRecipes () {
        return service.findAll();
    }

    /**
     * REST API method to provide GET access to a specific recipe, as indicated
     * by the path variable provided (the name of the recipe desired)
     *
     * @param name
     *            recipe name
     * @return response to the request
     */
    @GetMapping ( BASE_PATH + "/recipes/{name}" )
    public ResponseEntity getRecipe ( @PathVariable ( "name" ) final String name ) {
        final Recipe recipe = service.findByName( name );
        return null == recipe
                ? new ResponseEntity( errorResponse( "No recipe found with name " + name ), HttpStatus.NOT_FOUND )
                : new ResponseEntity( recipe, HttpStatus.OK );
    }

    /**
     * REST API method to provide POST access to the Recipe model. This is used
     * to create a new Recipe by automatically converting the JSON RequestBody
     * provided to a Recipe object. Invalid JSON will fail.
     *
     * @param recipe
     *            The valid Recipe to be saved.
     * @return ResponseEntity indicating success if the Recipe could be saved to
     *         the inventory, or an error if it could not be
     */
    @PostMapping ( BASE_PATH + "/recipes" )
    public ResponseEntity createRecipe ( @RequestBody final Recipe recipe ) {
        if ( null != service.findByName( recipe.getName() ) ) {
            return new ResponseEntity( errorResponse( "Recipe with the name " + recipe.getName() + " already exists" ),
                    HttpStatus.CONFLICT );
        }
        if ( service.findAll().size() < 3 ) {
            service.save( recipe );
            return new ResponseEntity( successResponse( recipe.getName() + " successfully created" ), HttpStatus.OK );
        }
        else {
            return new ResponseEntity(
                    errorResponse( "Insufficient space in recipe book for recipe " + recipe.getName() ),
                    HttpStatus.INSUFFICIENT_STORAGE );
        }
    }

    /**
     * REST API method to provide POST access to the Recipe model. This is used
     * to create a add an ingredient to a given recipe by automatically
     * converting the JSON RequestBody provided to a Recipe object. Invalid JSON
     * will fail.
     *
     * @param name
     *            refers to the name of the recipe
     * @param ingredient
     *            refers to the ingredient to be added
     * @return ResponseEntity indicating success if the Recipe could be saved to
     *         the inventory, or an error if it could not be
     */
    @PostMapping ( BASE_PATH + "/recipes/{name}/ingredient" )
    public ResponseEntity addIngredient ( @PathVariable ( "name" ) final String name,
            @RequestBody final Ingredient ingredient ) {
        final Recipe recipe = service.findByName( name );

        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + name ), HttpStatus.NOT_FOUND );
        }

        final Inventory i = ivt.getInventory();

        try {
            recipe.addIngredient( ingredient );
            service.save( recipe );
            if ( !i.containName( ingredient ) ) {
                final IngredientInInventory ivtName = new IngredientInInventory( ingredient.getName(), 100 );
                i.addIngredient( ivtName );
                ivt.save( i );

            }
            return new ResponseEntity( successResponse( name + " was updated successfully" ), HttpStatus.OK );
        }
        catch ( final IllegalArgumentException e ) {
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.CONFLICT );
        }
    }

    /**
     * REST API method to provide DELETE access to an Ingredient in the Recipe
     * model. This is used to delete an ingredient from a given recipe based on
     * the name given.
     *
     * @param name
     *            refers to the name of the recipe
     * @param ingredientName
     *            refers to the name of ingredient to delete
     * @return ResponseEntity indicating success if the ingredient could be
     *         deleted, or an error if it could not be
     */
    @DeleteMapping ( BASE_PATH + "/recipes/{name}/ingredient/{ingredientName}" )
    public ResponseEntity deleteIngredient ( @PathVariable ( "name" ) final String name,
            @PathVariable ( "ingredientName" ) final String ingredientName ) {
        final Recipe recipe = service.findByName( name );

        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + name ), HttpStatus.NOT_FOUND );
        }

        try {
            final Ingredient i = recipe.getIngredient( ingredientName );
            recipe.removeIngredient( ingredientName );
            service.save( recipe );
            iService.delete( i );
            return new ResponseEntity( successResponse( ingredientName + " was deleted succesfully" ), HttpStatus.OK );
        }
        catch ( final IllegalArgumentException e ) {
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.CONFLICT );
        }
    }

    /**
     * REST API method to provide PUT access to an Ingredient in the Recipe
     * model. This is used to edit the quantity of an ingredient in the recipe.
     *
     * @param name
     *            refers to the name of the recipe
     * @param ingredientName
     *            refers to the name of the ingredient to edit the quantity of
     * @param quantity
     *            refers to the updated quantity of the ingredient
     * @return ResponseEntity indicating success if the quantity could be
     *         updated, or an error if it could not be
     */
    @PutMapping ( BASE_PATH + "/recipes/{name}/ingredient/{ingredientName}" )
    public ResponseEntity editIngredient ( @PathVariable ( "name" ) final String name,
            @PathVariable ( "ingredientName" ) final String ingredientName, @RequestBody final int quantity ) {
        final Recipe recipe = service.findByName( name );

        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + name ), HttpStatus.NOT_FOUND );
        }

        try {
            recipe.editQuantity( ingredientName, quantity );
            service.save( recipe );
            return new ResponseEntity( successResponse( ingredientName + "was updated successfully" ), HttpStatus.OK );
        }
        catch ( final IllegalArgumentException e ) {
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.CONFLICT );
        }
    }

    /**
     * REST API method to provide GET access to an Ingredient in the Recipe
     * model. This is used to retrieve a specific ingredient with its name and
     * quantity for a particular recipe.
     *
     * @param recipeName
     *            refers to the name of the Recipe
     * @param ingredientName
     *            refers to the name of the Ingredient to be retrieved
     * @return ResponseEntity indicating success with the ingredient requested
     *         or an error if the ingredient could not be retrieved
     */
    @GetMapping ( BASE_PATH + "/recipes/{recipeName}/ingredient/{ingredientName}" )
    public ResponseEntity getIngredient ( @PathVariable ( "recipeName" ) final String recipeName,
            @PathVariable ( "ingredientName" ) final String ingredientName ) {
        final Recipe recipe = service.findByName( recipeName );

        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + recipeName ),
                    HttpStatus.NOT_FOUND );
        }

        final Ingredient ingredient = recipe.getIngredient( ingredientName );
        if ( ingredient == null ) {
            return new ResponseEntity( errorResponse( "No ingredient found for name " + ingredientName ),
                    HttpStatus.NOT_FOUND );
        }
        return new ResponseEntity( ingredient, HttpStatus.OK );

    }

    /**
     * REST API method to allow deleting a Recipe from the CoffeeMaker's
     * Inventory, by making a DELETE request to the API endpoint and indicating
     * the recipe to delete (as a path variable)
     *
     * @param name
     *            The name of the Recipe to delete
     * @return Success if the recipe could be deleted; an error if the recipe
     *         does not exist
     */
    @DeleteMapping ( BASE_PATH + "/recipes/{name}" )
    public ResponseEntity deleteRecipe ( @PathVariable final String name ) {
        final Recipe recipe = service.findByName( name );
        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + name ), HttpStatus.NOT_FOUND );
        }
        service.delete( recipe );

        return new ResponseEntity( successResponse( name + " was deleted successfully" ), HttpStatus.OK );
    }

    /**
     * REST API method to provide PUT access to the Recipe model. This is used
     * to update the current Recipe with a new recipe by automatically
     * converting the JSON RequestBody provided to a Recipe object.
     *
     * @param updatedRecipe
     *            recipe that is updated with this parameter
     * @return Success if the recipe is updated or an error if invalid
     */
    @PutMapping ( BASE_PATH + "/recipes/{name}" )
    public ResponseEntity editRecipe ( @RequestBody final Recipe updatedRecipe ) {
        final Recipe recipe = service.findByName( updatedRecipe.getName() );
        if ( null == recipe ) {
            return new ResponseEntity( errorResponse( "No recipe found for name " + updatedRecipe.getName() ),
                    HttpStatus.NOT_FOUND );
        }
        try {
            recipe.updateRecipe( updatedRecipe );
            service.save( recipe );
            return new ResponseEntity( successResponse( updatedRecipe.getName() + " was updated successfully" ),
                    HttpStatus.OK );
        }
        catch ( final IllegalArgumentException e ) {
            return new ResponseEntity( errorResponse( e.getMessage() ), HttpStatus.CONFLICT );
        }
    }
}
