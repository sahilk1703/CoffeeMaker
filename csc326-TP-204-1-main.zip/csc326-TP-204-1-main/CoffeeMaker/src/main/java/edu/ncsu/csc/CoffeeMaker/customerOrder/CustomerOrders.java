package edu.ncsu.csc.CoffeeMaker.customerOrder;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import edu.ncsu.csc.CoffeeMaker.models.DomainObject;
import edu.ncsu.csc.CoffeeMaker.models.Recipe;

/**
 * Represents an order placed by a customer in the CoffeeMaker application. This
 * entity class holds details about the order such as the associated recipes,
 * the order status, and the role of the user making the order. It includes
 * functionality to manage the lifecycle of an order, from creation through
 * various status changes to completion. The class is mapped as an entity with
 * its data being stored in a corresponding database table.
 *
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
@Entity
public class CustomerOrders extends DomainObject {

    /**
     * Unique identifier for the order
     */
    @Id
    @GeneratedValue
    private Long               id;

    /**
     * Identifier of the user who placed the order.
     */
    private Long               userId;

    /**
     * The list of recipes included in the order.
     */
    @OneToMany ( cascade = CascadeType.ALL, fetch = FetchType.EAGER )
    private List<Recipe>       recipe;

    /**
     * The current status of the order
     */
    private String             status;

    /**
     * The total number of items ordered.
     */
    private int                amount;

    /**
     * The number of items remaining to be delivered.
     */
    private int                remainingAmount;

    /**
     * The role of the individual associated with the order.
     */
    public String              role;

    /**
     * Status indicating the order is pending.
     */
    public static final String PENDING_STATUS   = "PENDING";

    /**
     * Status indicating the order has been cancelled.
     */
    public static final String CANCELLED_STATUS = "CANCELLED";

    /**
     * Status indicating the order is ready for pickup.
     */
    public static final String READY_FOR_PICKUP = "READY_FOR_PICKUP";

    /**
     * Status indicating the order is completed.
     */
    public static final String COMPLETED        = "COMPLETED";

    /** Role representing a customer */
    public static final String CUSTOMER_ROLE    = "Customer";

    /** Role representing a staff */
    public static final String STAFF_ROLE       = "Staff";

    /**
     * Default constructor for creating an instance without setting any initial
     * values.
     */
    public CustomerOrders () {
    }

    /**
     * Constructs a new CustomerOrders instance with specified details about the
     * order.
     *
     * @param userId
     *            the ID of the user placing the order
     * @param recipe
     *            the list of recipes included in the order
     * @param status
     *            the current status of the order
     * @param amount
     *            the total number of items in the order
     * @param role
     *            the role of the user placing the order
     */
    public CustomerOrders ( final Long userId, final List<Recipe> recipe, final String status, final int amount,
            final String role ) {
        setUserId( userId );
        setRecipe( recipe );
        setStatus( status );
        setAmount( amount );
        setRemainingAmount( amount );
        setRole( role );
    }

    /**
     * Sets the unique identifier for the order. Normally not used directly, as
     * ID is typically generated.
     *
     * @param orderId
     *            the new ID for the order
     */
    public void setId ( final Long orderId ) {
        this.id = orderId;
    }

    /**
     * Retrieves the unique identifier for the order.
     *
     * @return the unique ID of the order
     */
    @Override
    public Long getId () {
        return id;
    }

    /**
     * Retrieves the user ID associated with this order.
     *
     * @return the ID of the user who placed the order
     */
    public Long getUserId () {
        return userId;
    }

    /**
     * Sets the user ID for this order.
     *
     * @param userId
     *            the new user ID to be associated with this order
     */
    public void setUserId ( final Long userId ) {
        this.userId = userId;
    }

    /**
     * Retrieves the list of recipes associated with this order.
     *
     * @return a list of Recipe objects
     */
    public List<Recipe> getRecipe () {
        return recipe;
    }

    /**
     * Sets the recipes for this order. It ensures that the recipe list is not
     * null before setting it.
     *
     * @param recipe
     *            the new list of recipes to be associated with this order
     * @throws IllegalArgumentException
     *             if the recipe list is null
     */
    public void setRecipe ( final List<Recipe> recipe ) {
        if ( recipe == null ) {
            throw new IllegalArgumentException();
        }
        this.recipe = recipe;
    }

    /**
     * Retrieves the current status of the order.
     *
     * @return the status of the order
     */
    public String getStatus () {
        return status;
    }

    /**
     * Sets the status of this order. It validates that the status is not null
     * before setting.
     *
     * @param status
     *            the new status of the order
     * @throws IllegalArgumentException
     *             if the status is null
     */
    public void setStatus ( final String status ) {
        if ( status == null ) {
            throw new IllegalArgumentException();
        }
        this.status = status;
    }

    /**
     * Retrieves the total amount of items in the order.
     *
     * @return the total amount
     */
    public int getAmount () {
        return amount;
    }

    /**
     * Sets the total amount of items in the order. Validates that the amount is
     * not negative.
     *
     * @param amount
     *            the total amount of items in the order
     * @throws IllegalArgumentException
     *             if the amount is negative
     */
    public void setAmount ( final int amount ) {
        if ( amount < 0 ) {
            throw new IllegalArgumentException();
        }
        this.amount = amount;
    }

    /**
     * Retrieves the remaining amount of items to be processed in the order.
     *
     * @return the remaining amount of items
     */
    public int getRemainingAmount () {
        return remainingAmount;
    }

    /**
     * Sets the remaining amount of items in the order. Validates that the
     * remaining amount is not negative.
     *
     * @param remainingAmount
     *            the new remaining amount of items in the order
     * @throws IllegalArgumentException
     *             if the remaining amount is negative
     */
    public void setRemainingAmount ( final int remainingAmount ) {
        if ( remainingAmount < 0 ) {
            throw new IllegalArgumentException();
        }
        this.remainingAmount = remainingAmount;
    }

    /**
     * gets the user roles
     *
     * @return the role
     */
    public String getRole () {
        return role;
    }

    /**
     * Sets the user roles
     *
     * @param role
     *            the role to set
     */
    public void setRole ( final String role ) {
        if ( role == null || "".equals( role ) ) {
            throw new IllegalArgumentException( "Invalid user role." );
        }
        if ( !role.equals( CUSTOMER_ROLE ) && !role.equals( STAFF_ROLE ) ) {
            throw new IllegalArgumentException( "Inavlid user role." );
        }
        this.role = role;
    }

    /**
     * Updates the status of this order to a new value. This method might be
     * extended to include validation based on user roles or previous order
     * status.
     *
     * @param newStatus
     *            the new status to be set for the order
     */
    public void updateStatus ( final String newStatus ) {
        // if ( role.equals( CUSTOMER_ROLE ) ) {
        // throw new UnsupportedOperationException( "Customers cannot update the
        // order status." );
        // }
        setStatus( newStatus );

    }
}
