package edu.ncsu.csc.CoffeeMaker.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import edu.ncsu.csc.CoffeeMaker.models.Ingredient;
import edu.ncsu.csc.CoffeeMaker.repositories.IngredientRepository;

/**
 * The IngredientService is used to handle CRUD operations on the Ingredient
 * model. All of these functionalities represent those from 'Service'.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 */
@Component
@Transactional
public class IngredientService extends Service<Ingredient, Long> {

    /**
     * IngredientRepository, to be autowired in by Spring and provide CRUD
     * operations on the Ingredient model
     */
    @Autowired
    private IngredientRepository ingredientRepository;

    /**
     * Returns the instance of the ingredientRepository
     *
     * @return instance of the IngredientRepository
     */
    @Override
    protected JpaRepository<Ingredient, Long> getRepository () {
        return ingredientRepository;
    }

}
