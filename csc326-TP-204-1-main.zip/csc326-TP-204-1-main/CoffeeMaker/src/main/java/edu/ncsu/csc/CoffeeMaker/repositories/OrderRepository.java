package edu.ncsu.csc.CoffeeMaker.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ncsu.csc.CoffeeMaker.customerOrder.CustomerOrders;

/**
 * This class was implemented with the help of Generative AI Repository
 * interface for CustomerOrders providing standard operations and custom
 * queries.
 * 
 * @author shaziam
 * @author skancha5
 * @author rrjadhav
 * @author rakamani
 * @author skancha6
 * @author avenugo3
 */
public interface OrderRepository extends JpaRepository<CustomerOrders, Long> {

	/**
	 * Retrieves a list of CustomerOrders based on the specified status.
	 * 
	 * @param status The status to filter orders by.
	 * @return List of orders matching the status.
	 */
	List<CustomerOrders> findOrderByStatus(String status);

	/**
	 * Retrieves a list of CustomerOrders by order ID and status.
	 * 
	 * @param orderId The ID of the order.
	 * @param status  The status to filter orders by.
	 * @return List of matching orders.
	 */
	List<CustomerOrders> findByIdAndStatus(Long orderId, String status);

}
