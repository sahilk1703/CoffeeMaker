package edu.ncsu.csc.CoffeeMaker.models;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 * Ingredient for the coffee maker. Ingredient is tied to the database using
 * Hibernate libraries. See IngredientRepository and IngredientService for the
 * other two pieces used for database support.
 *
 * @author Satwika Kancharla
 * @author Rishima Jadhav
 * @author Shazia Muckram
 *
 */

@Entity
public class Ingredient extends DomainObject {

    /** Ingredient id */
    @Id
    @GeneratedValue
    Long    id;

    /** Type of Ingredient */
    String  name;

    /** Amount of Ingredient */
    Integer amount;

    /**
     * Creates a ingredient with the given ingredient and amount or the coffee
     * maker
     *
     * @param name
     *            for the type of the ingredient
     * @param amount
     *            for the initial amount of the ingredient
     */
    public Ingredient ( final String name, final Integer amount ) {
        setName( name );
        setAmount( amount );
    }

    /**
     * Creates a default ingredient for the coffee maker
     */
    public Ingredient () {
    }

    /**
     * Returns the type of ingredient
     *
     * @return the ingredient name
     */
    public String getName () {
        return name;
    }

    /**
     * Sets the type of ingredient
     *
     * @param name
     *            the ingredient to set
     */
    public void setName ( final String name ) {
        this.name = name;
    }

    /**
     * Returns the initial amount of ingredient
     *
     * @return the amount for the initial amount of the ingredient
     */
    public Integer getAmount () {
        return amount;
    }

    /**
     * Sets the initial amount of the ingredient
     *
     * @param amount
     *            the amount to set
     * @throws IllegalArgumentException
     *             for invalid price ( negative value ) of the ingredient
     */
    public void setAmount ( final Integer amount ) {
        if ( amount < 0 ) {
            throw new IllegalArgumentException( "Invalid units." );
        }
        this.amount = amount;
    }

    /**
     * Sets the id of the ingredient
     *
     * @param id
     *            the id to set
     */
    public void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Returns the ID of the entry in the DB
     *
     * @return id for the id of the ingredient
     */
    @Override
    public Serializable getId () {
        return id;
    }

    /**
     * Returns the ingredients with its id and initial amount in string format
     */
    @Override
    public String toString () {
        return "Ingredient [id=" + id + ", name=" + name + ", amount=" + amount + "]";
    }

}
