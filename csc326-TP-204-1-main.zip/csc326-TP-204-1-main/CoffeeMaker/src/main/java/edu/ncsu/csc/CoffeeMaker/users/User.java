package edu.ncsu.csc.CoffeeMaker.users;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

/**
 *
 * Represents a user in the Coffee Maker application. Users can have different
 * roles, such as Customer or Staff, and are identified by unique usernames.
 */
@Entity
public class User {

    /** Role representing a customer */
    public static final String CUSTOMER_ROLE = "Customer";
    /** Role representing a staff */
    public static final String STAFF_ROLE    = "Staff";
    /** Role representing a manager */
    public static final String MANAGER_ROLE  = "Manager";

    /** User first name */
    public String              firstName;
    /** User Last name */
    public String              lastName;
    /** Users username */
    public String              username;
    /** Users account password */
    private String             password;
    /** Users phone number */
    public String              phoneNumber;
    /** Users role such as staff or customer */
    public String              role;

    /**
     * The unique identifier for a user
     */
    @Id
    @GeneratedValue
    private Long               id;

    /**
     * Default constructor for creating a new User instance without setting any
     * attribute.
     */
    public User () {
        // default constructor
    }

    /**
     * Constructs a new User with specified details.
     *
     * @param fName
     *            First name of the user.
     * @param lName
     *            Last name of the user.
     * @param userusername
     *            Username of the user. Must be a valid email format.
     * @param userPassword
     *            Password of the user.
     * @param userPhoneNumber
     *            Phone number of the user.
     * @param userRole
     *            Role of the user. Can be either CUSTOMER_ROLE or STAFF_ROLE.
     */
    public User ( final String fName, final String lName, final String userusername, final String userPassword,
            final String userPhoneNumber, final String userRole ) {
        setFirstName( fName );
        setLastName( lName );
        setusername( userusername );
        setPassword( userPassword );
        setPhoneNumber( userPhoneNumber );
        setRole( userRole );
    }

    /**
     * Gets the first name
     *
     * @return the firstName
     */
    public String getFirstName () {
        return firstName;
    }

    /**
     * Sets the first name
     *
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName ( final String firstName ) {
        if ( firstName == null || "".equals( firstName ) ) {
            throw new IllegalArgumentException( "Invalid first name." );
        }
        this.firstName = firstName;
    }

    /**
     * Gets the last name
     *
     * @return the lastName
     */
    public String getLastName () {
        return lastName;
    }

    /**
     * sets the last name
     *
     * @param lastName
     *            the lastName to set
     */
    public void setLastName ( final String lastName ) {
        if ( lastName == null || "".equals( lastName ) ) {
            throw new IllegalArgumentException( "Invalid last name." );
        }
        this.lastName = lastName;
    }

    /**
     * gets the username
     *
     * @return the username
     */
    public String getusername () {
        return username;
    }

    /**
     * sets the username
     *
     * @param username
     *            the username to set
     */
    public void setusername ( final String username ) {
        if ( username == null || "".equals( username ) || !username.endsWith( ".com" ) || !username.contains( "@" )
                || username.indexOf( ".com" ) < username.indexOf( "@" ) ) {
            throw new IllegalArgumentException( "Invalid username address." );
        }
        this.username = username;
    }

    /**
     * gets the phone number
     *
     * @return the phoneNumber
     */
    public String getPhoneNumber () {
        return phoneNumber;
    }

    /**
     * sets the phone number
     *
     * @param phoneNumber
     *            the phoneNumber to set
     */
    public void setPhoneNumber ( final String phoneNumber ) {
        // if ( phoneNumber == null || phoneNumber.equals( "" ) ) {
        // throw new IllegalArgumentException( "Invalid phone number." );
        // }
        // try {
        // Integer.parseInt( phoneNumber );
        // }
        // catch ( final NumberFormatException e ) {
        // throw new IllegalArgumentException( "Invalid phone number." );
        // }
        this.phoneNumber = phoneNumber;
    }

    /**
     * gets the user roles
     *
     * @return the role
     */
    public String getRole () {
        return role;
    }

    /**
     * Sets teh user roles
     *
     * @param role
     *            the role to set
     */
    public void setRole ( final String role ) {
        if ( role == null || "".equals( role ) ) {
            throw new IllegalArgumentException( "Invalid user role." );
        }
        if ( !role.equals( CUSTOMER_ROLE ) && !role.equals( STAFF_ROLE ) && !role.equals( MANAGER_ROLE ) ) {
            throw new IllegalArgumentException( "Inavlid user role." );
        }
        this.role = role;
    }

    /**
     * Gets the password
     *
     * @return password of the account
     */
    public String getPassword () {
        return password;
    }

    /**
     * Sets teh password
     *
     * @param password
     *            password of the account
     */
    public void setPassword ( final String password ) {
        // if ( password == null || password.equals( "" ) ) {
        // throw new IllegalArgumentException( "Invalid password." );
        // }
        // if ( password.length() < 8 || ( !password.matches( "[a-zA-Z0-9]+" )
        // && !password.matches( "[A-Za-z0-9]+" ) ) ) {
        // throw new IllegalArgumentException( "Invalid password." );
        // }
        this.password = password;
    }

    /**
     * Sets the id
     *
     * @param id
     *            is of the user
     */
    @SuppressWarnings ( "unused" )
    private void setId ( final Long id ) {
        this.id = id;
    }

    /**
     * Gets the id
     *
     * @return id the id
     */
    public Long getId () {
        return id;
    }

    /**
     * Attempts to log in with the specified username and password.
     *
     * @param userusername
     *            The username to use for login.
     * @param userPassword
     *            The password to use for login.
     * @return true if login is successful, false otherwise.
     */
    public boolean login ( final String userusername, final String userPassword ) {
        if ( username.equals( userusername ) && password.equals( userPassword ) ) {
            return true;
        }
        return false;
    }

    // /**
    // * Compares this user to the specified object
    // *
    // * @param obj
    // * the object to compare this User against.
    // * @return true if the given object represents a User equivalent to this
    // * user, false otherwise.
    // */
    // @Override
    // public boolean equals ( final Object obj ) {
    // final User other = (User) obj;
    // return Objects.equals( username, other.username ) && Objects.equals(
    // firstName, other.firstName )
    // && Objects.equals( lastName, other.lastName ) && Objects.equals(
    // password, other.password )
    // && Objects.equals( phoneNumber, other.phoneNumber ) && Objects.equals(
    // role, other.role );
    // }

    /**
     * Returns a string representation of the User.
     *
     * @return a string representation of the User.
     */
    @Override
    public String toString () {
        return "User [firstName=" + firstName + ", lastName=" + lastName + ", username=" + username + ", password="
                + password + ", phoneNumber=" + phoneNumber + ", role=" + role + "]";
    }

}
